#!/usr/bin/env python3
# app.py - processed-video -> MJPEG (Flask) + RTSP (GStreamer appsrc)
# Requires: python3-gi, gstreamer1.0-*, opencv-python, pyyaml, flask, numpy
# HTTP MJPEG              http://192.168.1.47:5000              ---HTML
# HTTP MJPEG Server       http://192.168.1.47:5000/video_feed   ---VLC
# RTSP SERVER             http://192.168.1.47:8000/live         ---VLC
# TEST NOTES:4K INPUT TO 720P FRAME SPEED IS DROPPING...BUT RESOLUTION INPUT = OUTPUT WAS BETTER FRAME RATE.
# cam_imx415R1310 =EV       16 May 2026 Map Resolution to sink
# -*- coding: utf-8 -*-     30 May 2026 Multi Lanaguage with text size 2 firstly
# cam_imx415R1311 =EV       31 May 2026 Multi Lanaguge Input Display
# cam_imx415R1312 =EV       14 Jun 2026 OTA Update test

import gpiod
import cv2  
import yaml
import os
import copy
import threading
import time
import socket
import subprocess
import re                 #regular expression for generic_xy
import io
import numpy as np
import serial
import serial.tools.list_ports
import ota
#
import sys
import traceback
import subprocess



#multilangauge
import unicodedata
import regex as re
from wcwidth import wcwidth
from PIL import Image, ImageDraw, ImageFont

import arabic_reshaper
from bidi.algorithm import get_display

#unicode capable font

LANGUAGE_CONFIG = {
    "ENGLISH":   {"font": "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",             "y_offset": 0},
    "FRENCH":    {"font": "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",             "y_offset": 0},
    "GERMAN":    {"font": "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",             "y_offset": 0},
    "SPANISH":   {"font": "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",             "y_offset": 0},
    "ITALIAN":   {"font": "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",             "y_offset": 0},
    "PORTUGUESE":{"font": "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",             "y_offset": 0},
    "DUTCH":     {"font": "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",             "y_offset": 0},

    "RUSSIAN":   {"font": "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",             "y_offset": 0},
    "UKRAINIAN": {"font": "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",             "y_offset": 0},
    "GREEK":     {"font": "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",             "y_offset": 0},

    "THAI":      {"font": "/usr/share/fonts/truetype/noto/NotoSansThai-Regular.ttf",         "y_offset": 0},

    "ARABIC":    {"font": "/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf",       "y_offset": -2},

    "HINDI":     {"font": "/usr/share/fonts/truetype/noto/NotoSansDevanagari-Regular.ttf",   "y_offset": -2},

    "CHINESE":   {"font": "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",          "y_offset": -0},
    "TAIWANESE": {"font": "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",          "y_offset": -0},
    "JAPANESE":  {"font": "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",          "y_offset": -0},
    "KOREAN":    {"font": "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",          "y_offset": -0},
}
FONT_SIZES = {
    1: 12,
    2: 14,              #calibrated
    3: 16,
    4: 18,
    5: 20,
}

from datetime import datetime
from flask import Flask, Response, render_template, jsonify, request, send_from_directory

# GStreamer imports
import gi
gi.require_version('Gst', '1.0')
gi.require_version('GstRtspServer', '1.0')
from gi.repository import Gst, GstRtspServer, GLib



Gst.init(None)

# ---------- Load or create config ----------
CONFIG_FILE = "config.yaml"
DEFAULT_CONFIG = {
  "Video": {
    "Videoresolution": "720P",
    "Framerate": "25FPS",
    "brightness": 70,
    "contrast": 70,
    "saturation": 50,
    "hue": 50,
    "sharpness": 50,
    "Alarm_number": 1,    
    "Alarm_output": False,   
    "Alarm_state" : "NC",
    "Alarm_duration": 100, 
    "Trigger_text": "NO SALES",
    "AE": False,
    "exposure": 1200,
    "AGC": True,
    "analogue_gain": 100,
    "Vertical_flip": 0,
    "Horizontal_flip": 0,
    "Cam_port": 11
  },

  "Alarm": {
    "List": [
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "NO SALES" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "NO CHAGE" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "FREE ITEMS" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "GIFT" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "TRANSACTION BEGIN" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "TRANACTION END" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "SAMPLES" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" },
      { "Alarm_output": False, "Alarm_state": "NC", "Alarm_duration": 100, "Trigger_text": "" }
    ]
  },
  "Onscreen": {
    "Register": "GENERIC",
    "Titler": "VSI-PRO CAM1",
    "Titlerdisplay": True,
    "TDsync": True,
    "TDdisplay": True,
    "Timeformate": "12H",
    "Dateformate": "MM/DD/YY",
    "Vertical_Pos": 20,
    "Horizontal_Pos": 15,
    "Vertical_Max": 700,
    "Horizontal_Max": 1250,
    "Displayline": 42,
    "Spacingline": 4,
    "Displaywidth": 60,
    "TextSize": 2,
    "Textcolor": "white",
    "Backgroundcolor": "blue",
    "Textforeground": 255,
    "Textbackground": 60,
    "Screenblanking": 10,
    "Leftjustify": False,
    "Scrolldelay": False,
    "TextDisplay": True,
    "Language": "ENGLISH",
    "Bold": 1
  },
  "Communications": {
    "Streammode": "HTTP/RTSP",
    "IP": "192.168.1.47",
    "Gateway": "192.168.1.1",
    "Subnet": "255.255.255.0",
    "Streamport": 554,                     #554, Test 8000
    "Httpport": 80,                       #80, Test 80
    "ApplyNetwork": False,
    "InputSelection": "Serial",
    "Overlayport": 9100,
    "TargetIP": "192.168.1.43",
    "Miror_Output": False,
    "Mirorport": 9101,
    "Textprotocol": "TCP",
    "interface": "eth0",
    "BaudRate": 9600,
    "DataBits": 8,
    "StopBits": 1,
    "Parity": "NONE",
    "HandShaking": "OFF"
  },
  "Password": {
    "Username": "user",
    "Password": "user123",
    "FactoryReset": False,
    "factoryname": "admin",
    "factoryPassword": "admin123"
  },
"System": {
  "Version": "100R1",
  "UpdateState": "IDLE",        
  "UpdateRequested": False,  
  "RebootRequired": False,
  "RestartStream": False,      
  "RestartHTTP": False,        
  "RestartCapture": False,   
  "ApplyNetwork": False,
  "ReloadUI": False,     
  "LastError": "",
  "LastAction": "",   
  "LastUpdateTime": ""          
}

}

#Change according Filter Selection
FILTER_DEFAULTS = {
    "GENERIC": {
        "Communications": {
            "InputSelection": "Serial",
            "BaudRate": 9600,      # number
            "DataBits": 8,         # number
            "StopBits": 1,         # number
            "Parity": "NONE",
            "Miror_Output": True
        },
    },
    "GENERIC-XY": {
        "Communications": {
            "InputSelection": "Serial",
            "BaudRate": 9600,      # number
            "DataBits": 7,         # number
            "StopBits": 1,         # number
            "Parity": "EVEN",
            "Miror_Output": False           
        },
  
    },
    "GENERIC-NT": {
        "Communications": {
            "InputSelection": "Network",
            "Textprotocol": "TCP",
             "Miror_Output": True
        },
      
    },   
    "GENERIC-XYNT": {
        "Communications": {
            "InputSelection": "Network",
            "Textprotocol": "TCP",
            "Miror_Output": False
        },
    
    }   
       
}


#Change according Resolutions
RESOLUTION_DEFAULTS = {
    "720P": {
        "Vertical_Pos": 30,
        "Horizontal_Pos": 50,
        "Vertical_Max": 700,
        "Horizontal_Max": 1250,
        "Displayline": 42,
        "Displaywidth": 60,
        "TextSize": 2,
        "Bold": 1,                      #integrator only 1 2 3 4 not 2.5
    },
    "1080P": {
        "Vertical_Pos": 35,
        "Horizontal_Pos": 50,       
        "Vertical_Max": 1000,
        "Horizontal_Max": 1900,
        "Displayline": 52,
        "Displaywidth": 70,
        "TextSize": 2,
        "Bold": 1,
    },
    "1440P": {
        "Vertical_Pos": 50,
        "Horizontal_Pos": 50,       
        "Vertical_Max": 1440,
        "Horizontal_Max": 2560,
        "Displayline": 62,
        "Displaywidth": 70,
        "TextSize": 3,
        "Bold": 2,
    },
    "4K": {
        "Vertical_Pos": 60,
        "Horizontal_Pos": 60,
        "Vertical_Max": 2100,
        "Horizontal_Max": 3800,
        "Displayline": 82,
        "Displaywidth": 70,
        "TextSize": 4,
        "Bold": 3,
    },
}

config_lock = threading.Lock()
config = {}

import struct

def cidr_to_subnet(cidr):
    mask = (0xffffffff >> (32 - cidr)) << (32 - cidr)
    return socket.inet_ntoa(struct.pack(">I", mask))

#merge config with yaml
def merge_defaults(cfg, defaults):
    """
    Merge defaults into cfg:
    - Add missing keys from defaults
    - Remove keys not in defaults
    """
    # Remove keys not in defaults
    for key in list(cfg.keys()):
        if key not in defaults:
            del cfg[key]

    # Add missing keys and merge sub-dicts
    for key, value in defaults.items():
        if isinstance(value, dict):
            cfg[key] = merge_defaults(cfg.get(key, {}), value)
        else:
            if key not in cfg:
                cfg[key] = value
    return cfg
#Original with merging but not work
"""
def load_or_create_config():
    global config

    full_path = os.path.abspath(CONFIG_FILE)
    print("Config file full path:", full_path)

    # Ensure directory exists
    config_dir = os.path.dirname(full_path) or "."
    if not os.path.exists(config_dir):
        print("Creating directory:", config_dir)
        os.makedirs(config_dir, exist_ok=True)

    # Load file if exists
    if os.path.exists(full_path):
        try:
            with open(full_path, "r") as f:
                loaded = yaml.safe_load(f) or {}
            print("Loaded existing config.yaml")
        except Exception as e:
            print("Error loading config file:", e)
            loaded = {}
    else:
        print("Config not found, creating new with defaults.")
        loaded = {}

    # Merge defaults
    for section, defaults in DEFAULT_CONFIG.items():

        # Dictionary section
        if isinstance(defaults, dict):
            if section not in loaded or not isinstance(loaded.get(section), dict):
                loaded[section] = copy.deepcopy(defaults)
            else:
                for k, v in defaults.items():
                    if k not in loaded[section]:
                        loaded[section][k] = v

        # Non-dict (flat values)
        else:
            if section not in loaded:
                loaded[section] = defaults

    config = loaded

    # Write YAML
    try:
        with open(full_path, "w") as f:
            yaml.dump(config, f, sort_keys=False)
        print("Config saved to:", full_path)
    except Exception as e:
        print("Config write error:", e)
"""
def load_or_create_config():
    global config

    full_path = os.path.abspath(CONFIG_FILE)
    print("Config file full path:", full_path)

    # Ensure directory exists
    config_dir = os.path.dirname(full_path) or "."
    if not os.path.exists(config_dir):
        print("Creating directory:", config_dir)
        os.makedirs(config_dir, exist_ok=True)

    # Load file if exists
    if os.path.exists(full_path):
        try:
            with open(full_path, "r") as f:
                loaded = yaml.safe_load(f) or {}
            print("Loaded existing config.yaml")
        except Exception as e:
            print("Error loading config file:", e)
            loaded = {}
    else:
        print("Config not found, creating new with defaults.")
        loaded = {}

    # Merge defaults strictly
    config = merge_defaults(loaded, DEFAULT_CONFIG)

    # Save YAML
    try:
        with open(full_path, "w") as f:
            yaml.dump(config, f, sort_keys=False)
        print("Config saved to:", full_path)
    except Exception as e:
        print("Config write error:", e)

    return config

RES_MAP = {
    "720P":  (1280, 720),
    "1080P": (1920, 1080),
    "1440P": (2560, 1440),
    "4K":    (3840, 2160),
}
def get_resolution(res_name):
    return RES_MAP.get(res_name.upper(), (1280, 720))
def parse_fps(s):
    try:
        return int(''.join(ch for ch in s if ch.isdigit()) or 25)
    except:
        return 25

def parse_fps_safe(fps_value):
    try:
        if isinstance(fps_value, int):
            return fps_value
        return int(''.join(ch for ch in str(fps_value) if ch.isdigit()) or 25)
    except:
        return 25

def get_target_fps():
    with config_lock:
        cfg = config.get("Video", {})
        return max(parse_fps_safe(cfg.get("Framerate", "25FPS")), 1)
        


def parse_color(name, level=255):
    """
    Convert color name + intensity level to BGR tuple.
    level: 0-255 intensity scaling
    """
    if not name:
        name = "white"
    base = color_map.get(name.lower(), (255, 255, 255))
    scale = level / 255.0
    return tuple(int(c * scale) for c in base)
def apply_intensity(color_rgb, intensity):
    factor = intensity / 255.0
    return tuple(int(c * factor) for c in color_rgb)
def compute_font_scale(video_res, base_scale=0.5):
    scale_map = {
        "720P": 0.25,
        "1080P": 0.5,
        "1440P": 0.75,
        "4K": 1.0,
    }
    return base_scale * scale_map.get(video_res, 1.0)


#text Size cannot be 0 we will use 1 (size0) 2(size1) 3(size2) 4(size3) 5(size4)
def normalize_text_size(value):
    try:
        value = int(value)
    except (TypeError, ValueError):
        return 1

    if value < 1 or value > 6:
        return 1

    return value


color_map = {
    "black":  (0, 0, 0),
    "white":  (255, 255, 255),
    "red":    (0, 0, 255),
    "green":  (0, 255, 0),
    "blue":   (255, 0, 0),
    "yellow": (0, 255, 255),
    "orange": (0, 165, 255),
}


#ENGLISH
font = cv2.FONT_HERSHEY_SIMPLEX
# Text buffer state (shared)
scrolling_rows = []
last_text_time = time.time()
last_scroll_time = 0
scroll_index = 0
clear_screen = False
SCROLL_DELAY_ON = 1.250    # 1250ms
SCROLL_DELAY_OFF = 0.250   # 250ms

text_buffer = ""  # keep this a string here
temp_buffer = ""


shadow_color = (0,0,0)             #shadow Color
shadow_offset = (1,1)              #text shadow

GPIO_CHIP = "gpiochip1"
GPIO_LINE = 10

chip = gpiod.Chip(GPIO_CHIP)
line = chip.get_line(GPIO_LINE)

# Globals initialized here****************************************************************

CAP_WIDTH = 1280
CAP_HEIGHT = 720
FPS = 25
CAM_PORT = 11
cap = None

host_ip = "0.0.0.0"
STREAM_PORT = 8554
HTTP_PORT = 5000
OVERLAY_PORT = 9100

USE_TCP = True
MIRROR_OUTPUT = False

MIRROR_IP = "127.0.0.1"
MIRROR_PORT = 910

# Color gains #when red is orange reduce read increase blue
red_gain = 0.5250
green_gain = 0.2650                 
blue_gain = 0.1155


last_text_size = None           #Restrat CV Thread when Size Change
last_register = None            #Defualt Network or Serial Setup Change
last_resolution = None          #default Onscree Setup when resolution change
last_metrics = None             #update text programming setup

td_enabled = 1
titler_enabled = 1
text_display_enabled = True
scroll_delay_enabled = False
screen_blanking = 0
left_justify = False

TD_format = "MM/DD/YY"
hour_format = "24H"
camera_title_text = ""

#text screen handler
base_x = 14
base_y = 14
header_rows = 0
title_start_xy = (14, 14)
row_width = 30
max_rows = 42
font_scale = 0.5
line_height = 14
num_rows = 42
font_thickness = 4
font_color = (255, 255, 255)
background_color = (0, 0, 0)
background_alpha = 0.0

brightness_pct = 50
contrast_pct = 50
saturation_pct = 50
hue_pct = 50
sharpness_pct = 50

#auto video adjust
video = {}
auto_exposure = 1000
auto_gain = 100
ae_enabled = False
agc_enabled = False
manual_gain = 60
manual_exposure = 800

frame_count = 0
prev_luma = None
prev_exp_out = None
prev_gain_out = None
stable_counter = 0


language_now = "ENGLISH"
file_size = 16
font_file =  "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf"
y_offset = 0
spacing_line = 0

FONT_UNI = ImageFont.truetype(font_file,  file_size, y_offset)
FONT_EN = ImageFont.truetype(font_file,  file_size)

mirror_warning_text = (
    f"WARNING: Mirror {MIRROR_IP}:{MIRROR_PORT} not available"
)

ser = serial
baud = 9600
databits = 8
stopbits = 1
parity = "NONE"

#ANY UNICODE LANGUAGE INLCUDE THAI 
# -----------------------------
import regex as re
GRAPHEME = re.compile(r'\X')

def split_graphemes(text):
    return GRAPHEME.findall(text)

def char_width(ch):
    w = wcwidth(ch)
    return max(w, 1)

def wrap_unicode(text, max_width):
    text = unicodedata.normalize("NFC", text)

    chars = split_graphemes(text)

    lines = []
    current = ""
    width = 0

    for ch in chars:
        if ch in "\r\n":
            continue

        w = char_width(ch)

        if width + w > max_width:
            lines.append(current)
            current = ch
            width = w
        else:
            current += ch
            width += w

    if current:
        lines.append(current)

    return lines

def unicode_slice(text, max_width):
    chars = GRAPHEME.findall(text)

    out = ""
    width = 0

    for ch in chars:
        w = 1  # keep SAME behavior as generic row_width logic

        if width + w > max_width:
            break

        out += ch
        width += w

    return out



#Luma 16-235            Dark to  White
# =====================================================
# AE / AGC GLOBAL TUNING
# =====================================================

LUMA_BLACK_OFFSET = 35
LUMA_WHITE_OFFSET = 235
LUMA_OFFSET = 60      # 🔥 main brightness calibration (tune 15–30

register_type = "GENERIC-SL"
langauge_type ="ENGLISH"
serial_stop_event = threading.Event()
text_thread = None

latest_frame_for_luma = None
last_print_time = 0
last_mode = None

system_mode = "INIT"

init_done = False
init_locked_exp = None
init_locked_gain = None

prev_init_luma = 0
init_samples = []

    

def luma_monitor():
    global latest_frame_for_luma

    while True:
        if latest_frame_for_luma is not None:
            frame = latest_frame_for_luma.copy()

            luma_avg, luma_min, luma_max, _, hi_ratio, sh_ratio = compute_luma(frame)

            print(
                f"[LUMA] avg={luma_avg:.1f} "
                f"min={luma_min:.1f} max={luma_max:.1f} "
                f"hi={hi_ratio:.2f} sh={sh_ratio:.2f}"
            )

        time.sleep(5)
threading.Thread(target=luma_monitor, daemon=True).start()

def compute_luma(frame):
    y = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)[:, :, 0]

    luma_avg = np.percentile(y, 60)
    luma_min = np.percentile(y, 5)
    luma_max = np.percentile(y, 95)

    hi_ratio = np.mean(y > 240)
    sh_ratio = np.mean(y < 20)

    return luma_avg, luma_min, luma_max, y, hi_ratio, sh_ratio

def set_ctrl(name, value):
    try:
        subprocess.run([
            "v4l2-ctl",
            "-d", "/dev/v4l-subdev2",
            "--set-ctrl", f"{name}={int(value)}"
        ], check=True)
    except Exception as e:
        print(f"[CTRL ERROR] {name}={value} -> {e}")
def get_video_config():
    with config_lock:
        return config.get("Video", {}).copy()


def init_camera():

    global cap

    with config_lock:
        cfg = globals()["config"]
        video = cfg.get("Video", {})

        res_name = video.get("Videoresolution", "1080P")
        fps_value = video.get("Framerate", "25FPS")

    width, height = get_resolution(res_name)
    fps = parse_fps_safe(fps_value)

    print(f"[CAMERA CONFIG] {res_name} -> {width}x{height} @ {fps}")

    if cap:
        cap.release()
        cap = None
        time.sleep(0.5)

    GST_PIPELINE = (
            f"v4l2src device=/dev/video11 io-mode=4 ! "
            f"video/x-raw,format=NV12,width={width},height={height},framerate={fps}/1 ! "
            f"videoconvert ! "
            f"video/x-raw,format=BGR ! "
            f"appsink drop=true max-buffers=1 sync=false"
        )

    print(f"[GST] {GST_PIPELINE}")

    cap = cv2.VideoCapture(GST_PIPELINE, cv2.CAP_GSTREAMER)

    if not cap.isOpened():
        raise RuntimeError("RKISP camera open failed")

    print(f"[CAMERA] READY {width}x{height}@{fps}")
def wait_for_camera_ready(cap, timeout=5):
    """
    RKISP-safe readiness check:
    waits until pipeline produces valid frames without breaking stream
    """

    start = time.time()
    fail_count = 0

    while time.time() - start < timeout:

        # -------------------------------------------------
        # 1. cap must exist and be opened
        # -------------------------------------------------
        if cap is None or not cap.isOpened():
            time.sleep(0.1)
            continue

        # -------------------------------------------------
        # 2. try read frame (non-blocking validation)
        # -------------------------------------------------
        ret, frame = cap.read()

        if ret and frame is not None and frame.size > 0:
            print("[CAMERA] Ready")
            return True

        # -------------------------------------------------
        # 3. small failure tolerance (RKISP warm-up)
        # -------------------------------------------------
        fail_count += 1

        if fail_count > 3:
            print("[CAMERA] warming up...")

        time.sleep(0.1)

    print("[CAMERA] NOT READY (timeout)")
    return False
def open_serial_port():
    global baud, databits, stopbits, parity, ser
    
    comm = config.get("Communications", {})

    # --- Read config (YAML-safe) ---    
    #baud = int(comm.get("BaudRate", 9600))
    #databits = str(comm.get("DataBits", 8)).strip()
    #stopbits = str(comm.get("StopBits", 1)).strip()
    #parity = str(comm.get("Parity", "NONE")).upper()

    # Optional (recommended)
    port = comm.get("SerialPort", "/dev/ttyS7")

    # --- pySerial mappings ---
    byte_sizes = {
        "7": serial.SEVENBITS,
        "8": serial.EIGHTBITS
    }

    parity_map = {
        "NONE": serial.PARITY_NONE,
        "EVEN": serial.PARITY_EVEN,
        "ODD": serial.PARITY_ODD
    }

    stopbit_map = {
        "1": serial.STOPBITS_ONE,
        "2": serial.STOPBITS_TWO
    }

    try:
        ser = serial.Serial(
            port=port,
            baudrate=baud,
            bytesize=byte_sizes.get(databits, serial.EIGHTBITS),
            parity=parity_map.get(parity, serial.PARITY_NONE),
            stopbits=stopbit_map.get(stopbits, serial.STOPBITS_ONE),
            timeout=0.1
        )

        print(
            f"[SERIAL] Opened {port} | "
            f"{baud}bps {databits}{parity}/{stopbits}"
        )
        return ser

    except Exception as e:
        raise RuntimeError(f"Serial open failed ({port}): {e}")
    
def reopen_serial_port():
    global ser

    if ser:
        try:
            ser.close()
            print("[SERIAL] Closed")
        except Exception as e:
            print("[SERIAL] Close error:", e)

    ser = open_serial_port()

def reload_derived_config():
    global CAP_WIDTH, CAP_HEIGHT, FPS, CAM_PORT
    global host_ip, STREAM_PORT, HTTP_PORT, OVERLAY_PORT, USE_TCP
    global MIRROR_OUTPUT, MIRROR_IP, MIRROR_PORT
    global font_scale, line_height, num_rows, font_thickness
    global font_color, background_color, background_alpha
    global td_enabled, titler_enabled, text_display_enabled, scroll_delay_enabled, screen_blanking
    global left_justify, TD_format, hour_format, camera_title_text
    global base_x, base_y, header_rows, title_start_xy, row_width, max_rows, spacing_line
    global brightness_pct, contrast_pct, saturation_pct, hue_pct, sharpness_pct
    global register_type
    global langauge_type
    global font, language_now, file_size, font_file, FONT_UNI, y_offset, FONT_EN
    global text_size     # <-- ADD THIS
    global onscreen      # <-- ADD THIS if onscreen was global
    global display_line_map, font_scale_map, line_height_map
    global text_width, text_height, fixed_baseline   
    global ae_enabled, agc_enabled, manual_gain, manual_exposure
    global mirror_warning_text
    global baud, databits, stopbits,parity
 
    onscreen = config.get("Onscreen", {})

    # Load text size and related params again
    text_size = onscreen.get("TextSize", 2)
    language_now = onscreen.get("Language", "ENGLISH")
    num_rows = int(onscreen.get("Displayline", 42))
    font_thickness = onscreen.get("TextBold", 2)
    spacing_line = onscreen.get("Spacingline", 2) 
    row_width = onscreen.get("Displaywidth", 30)


    with config_lock:
        video_cfg = config["Video"]
        onscreen = config["Onscreen"]
        comm = config["Communications"]

        CAP_WIDTH, CAP_HEIGHT = get_resolution(video_cfg.get("Videoresolution", "720P"))
        FPS = parse_fps(video_cfg.get("Framerate", "25FPS"))
        CAM_PORT = video_cfg.get("Cam_port", 11)

        host_ip = comm.get("IP", "0.0.0.0")
        STREAM_PORT = int(comm.get("Streamport", 8554))
        HTTP_PORT = int(comm.get("Httpport", 5000))

        OVERLAY_PORT = int(comm.get("Overlayport", 9100))
        USE_TCP = comm.get("Textprotocol", "TCP").upper() == "TCP"
        MIRROR_OUTPUT = comm.get("Miror_Output", False)
        MIRROR_IP = comm.get("TargetIP", host_ip)
        MIRROR_PORT = int(comm.get("Mirorport", 9101))
        baud = int(comm.get("BaudRate", 9600))
        databits = int(comm.get("DataBits", 8))
        stopbits = int(comm.get("StopBits", 1))
        parity = str(comm.get("Parity", "NONE")).upper()

        mirror_warning_text = (
            f"WARNING: Mirror {MIRROR_IP}:{MIRROR_PORT} not avialable"
        )

        text_size = onscreen.get("TextSize", 2)
        language_now = onscreen.get("Language", "ENGLISH")
        num_rows = int(onscreen.get("Displayline", 42))
        font_thickness = onscreen.get("Bold", 2) 
        spacing_line = onscreen.get("Spacingline", 2) 
        lang_cfg = LANGUAGE_CONFIG.get(
            language_now,
            LANGUAGE_CONFIG["ENGLISH"]
        )
        font_file = lang_cfg["font"]
        y_offset = lang_cfg["y_offset"]

        file_size = FONT_SIZES.get(text_size, 16)

        FONT_UNI = ImageFont.truetype(font_file, file_size)
        FONT_EN = ImageFont.truetype("/usr/share/fonts/truetype/noto/NotoSansMono-Medium.ttf", file_size)

        text_color_name = onscreen.get("Textcolor", "white").lower()
        background_color_name = onscreen.get("Backgroundcolor", "black").lower()
        text_foreground_intensity = onscreen.get("Textforeground", 255)
        text_background_intensity = onscreen.get("Textbackground", 10)
        font_color = apply_intensity(color_map.get(text_color_name, (255, 255, 255)), text_foreground_intensity)
        background_color = color_map.get(background_color_name, (0, 0, 0))
        background_alpha = text_background_intensity / 255.0 if text_background_intensity > 0 else 0.0

        td_enabled = 1 if onscreen.get("TDdisplay", False) else 0
        titler_enabled = 1 if onscreen.get("Titlerdisplay", False) else 0
        text_display_enabled = onscreen.get("TextDisplay", True)
        scroll_delay_enabled = onscreen.get("Scrolldelay", False)
        screen_blanking = onscreen.get("Screenblanking", 0)
        left_justify = onscreen.get("Leftjustify", False)
        TD_format = onscreen.get("Dateformat", "MM/DD/YY")
        hour_format = onscreen.get("Timeformate", "24H")
        camera_title_text = onscreen.get("Titler", "")

        base_x = onscreen.get("Horizontal_Pos", 14)
        base_y = onscreen.get("Vertical_Pos", 14)
        header_rows = td_enabled + titler_enabled
        title_start_xy = (base_x, base_y + header_rows * line_height)
        row_width = onscreen.get("Displaywidth", 30)
        max_rows = num_rows

        brightness_pct = video_cfg.get("brightness", 50)
        contrast_pct = video_cfg.get("contrast", 50)
        saturation_pct = video_cfg.get("saturation", 50)
        hue_pct = video_cfg.get("hue", 50)
        sharpness_pct = video_cfg.get("sharpness", 50)


        ae_enabled = bool(video_cfg.get("AE", False))
        agc_enabled = bool(video_cfg.get("AGC", False))

        manual_exposure = int(video_cfg.get("exposure", 800))
        manual_gain = int(video_cfg.get("analogue_gain", 60))        

        register_type = onscreen.get("Register","GENERIC")
        langauge_type = onscreen.get("language","ENGLISH")
        # =====================================================
        # 🔥 IMPORTANT: sync runtime video dict (CRITICAL FIX)
        # =====================================================
        if "video" in globals():
            video["AE"] = ae_enabled
            video["AGC"] = agc_enabled
            video["exposure"] = manual_exposure
            video["analogue_gain"] = manual_gain        
        #load_or_create_config()
        #reload_derived_config()
def get_formatted_timestamp():
    now = datetime.now()

    WEEKDAYS = ["MON","TUE","WED","THU","FRI","SAT","SUN"]
    day_of_week = WEEKDAYS[now.weekday()]

    # Always fetch the latest config from memory
    onscreen = config.get("Onscreen", {})
    TD_format = onscreen.get("Dateformate", "MM/DD/YY")
    hour_format = onscreen.get("Timeformate", "12H")

    # ----- DATE FORMAT -----
    if TD_format == "MM/DD/YY":
        date_str = now.strftime("%m/%d/%y")
    elif TD_format == "DD/MM/YY":
        date_str = now.strftime("%d/%m/%y")
    elif TD_format == "YY/MM/DD":
        date_str = now.strftime("%y/%m/%d")
    else:
        date_str = now.strftime("%m/%d/%y")

    # ----- TIME FORMAT -----
    if hour_format == "12H":
        time_str = now.strftime("%I:%M:%S %p")
    else:
        time_str = now.strftime("%H:%M:%S")

    return f"{time_str} : {date_str} : {day_of_week}"   
def clear_text_area(frame, start_y, line_height, num_rows, start_x, width):
    height = line_height * num_rows
    # Fill the rectangle where text appears with black (or your background color)
    cv2.rectangle(frame, (start_x, start_y), (start_x + width, start_y + height), (0, 0, 0), thickness=cv2.FILLED)

#ALARM BLINKING###############################################################################
alarm_visible = False
last_blink_time = 0
BLINK_INTERVAL = 1.0  # 1 second

def get_alarm_x(text):
    display_width = int(config["Onscreen"]["Displaywidth"])
    padding_x = 4

    (char_w, _), _ = cv2.getTextSize("W", font, font_scale, font_thickness)

    total_w = display_width * char_w

    # clamp text length to display width
    text_len = min(len(text), display_width)

    text_w = (text_len+2* padding_x) * char_w

    # right aligned inside padding
    x = base_x + total_w - text_w - padding_x

    return int(x)
def update_alarm_visual():
    global alarm_visible, last_blink_time

    if not alarm_active:
        alarm_visible = False
        return

    now = time.time()

    if now - last_blink_time >= BLINK_INTERVAL:
        alarm_visible = not alarm_visible
        last_blink_time = now
def get_alarm_anchor_mode(td_enabled, titler_enabled):
    if td_enabled:
        return "TD"
    elif titler_enabled:
        return "TITLER"
    else:
        return "INSERT"
def draw_alarm(adjusted, y, anchor_mode, anchor_y=None):
    update_alarm_visual()

    alarm_text = "((o))"
    #alarm_text = "WWWWW"        #Test
    alarm_x = get_alarm_x(alarm_text)

    # TD / TITLER overlay
    if anchor_mode in ("TD", "TITLER") and anchor_y is not None:
        if alarm_visible:
            draw_text_with_shadow(adjusted, alarm_text, (alarm_x, anchor_y))
        return y

    # INSERT mode (stable layout)
    if anchor_mode == "INSERT" and alarm_active:
        if alarm_visible:
            draw_text_with_shadow(adjusted, alarm_text, (alarm_x, y))
        return y + line_height

    return y
#ALARM PROCESS###############################################################################
alarm_active = False
alarm_end_time = 0
alarm_lock = threading.Lock()

def init_alarm_gpio():
    global gpio_chip, gpio_line

    try:
        gpio_chip = gpiod.Chip(GPIO_CHIP)
        gpio_line = gpio_chip.get_line(GPIO_LINE)

        video = config.get("Video", {})
        state = video.get("Alarm_state", "NC")

        # 🔥 Set correct idle level
        idle_value = 1 if state == "NC" else 0

        gpio_line.request(
            consumer="alarm",
            type=gpiod.LINE_REQ_DIR_OUT,
            default_vals=[idle_value]
        )

        print(f"[GPIO] Init {GPIO_CHIP}:{GPIO_LINE} idle={idle_value}")

    except Exception as e:
        print("[GPIO] Init error:", e)
def trigger_alarm():
    global alarm_active, alarm_end_time

    video = config.get("Video", {})
    duration_sec = video.get("Alarm_duration", 100)

    with alarm_lock:
        now = time.time()

        # 🔥 Extend timer every time trigger happens
        alarm_end_time = now + duration_sec

        if not alarm_active:
            print("[ALARM] START")
            alarm_active = True
            set_alarm_output(True)
def check_alarm_trigger(text):
    video = config.get("Video", {})

    if not video.get("Alarm_output", False):
        return

    trigger = video.get("Trigger_text", "").strip()

    if not trigger:
        return

    # 🔥 match condition
    if trigger.lower() in text.lower():
        print(f"[ALARM] MATCH: {trigger}")
        trigger_alarm()
def set_alarm_output(active):
    global gpio_line

    video = config.get("Video", {})
    state = video.get("Alarm_state", "NC")

    # Determine correct output level
    if state == "NO":
        value = 1 if active else 0
    else:  # NC
        value = 0 if active else 1

    try:
        if gpio_line:
            gpio_line.set_value(value)   # ✅ THIS is where it belongs
        print(f"[GPIO] state={state} active={active} → value={value}")
    except Exception as e:
        print("[GPIO] Error:", e)
def alarm_worker():
    global alarm_active

    while True:
        time.sleep(0.05)

        if not alarm_active:
            continue

        with alarm_lock:
            if time.time() >= alarm_end_time:
                print("[ALARM] STOP")
                alarm_active = False
                set_alarm_output(False)   

alarm_thread = threading.Thread(target=alarm_worker, daemon=True)
alarm_thread.start()

#TEXT FILTERS##############################################################################################
generic_xy_texts = []  # global list of dicts with keys: x, y, text
"""
def update_scrolling_text(new_text=None, force_new_row=False, force_display=True):

    global scrolling_rows
    global text_buffer
    global temp_buffer
    global scroll_index
    global last_scroll_time
    global last_text_time
    global clear_screen

    # ==========================================
    # ADD NEW TEXT
    # ==========================================
    if new_text is not None:

        segment = new_text or " "

        if force_new_row:

            scrolling_rows.append(segment)

            # restart scrolling from top when new data arrives
            scroll_index = 0

        else:

            text_buffer = segment

            if scrolling_rows:
                scrolling_rows[-1] = text_buffer
            else:
                scrolling_rows.append(text_buffer)

        last_text_time = time.time()
        clear_screen = False

    # ==========================================
    # SCREEN BLANKING
    # ==========================================
    if screen_blanking:

        if time.time() - last_text_time > screen_blanking:

            scrolling_rows.clear()

            text_buffer = ""
            temp_buffer = ""

            scroll_index = 0

            clear_screen = True

    # ==========================================
    # AUTO SCROLL
    # ==========================================
    total_rows = len(scrolling_rows)

    if scroll_delay_enabled and total_rows > num_rows:

        max_scroll = total_rows - num_rows

        if (
            time.time() - last_scroll_time >= 1.0
            and scroll_index < max_scroll
        ):

            scroll_index += 1
            last_scroll_time = time.time()

            print(
                f"[SCROLL] index={scroll_index} "
                f"max={max_scroll}"
            )

    # ==========================================
    # VISIBLE WINDOW
    # ==========================================
    start = scroll_index
    end = start + num_rows

    visible_rows = scrolling_rows[start:end]

    return visible_rows, clear_screen
"""
def update_scrolling_text(new_text=None, force_new_row=False, force_display=True):

    global scrolling_rows
    global text_buffer
    global temp_buffer

    global scroll_index
    global last_scroll_time
    global last_text_time
    global clear_screen

    now = time.time()

    # =====================================================
    # NEW TEXT ARRIVED
    # =====================================================
    if new_text is not None:

        segment = new_text or " "

        if force_new_row:

            scrolling_rows.append(segment)

            # Restart scrolling for newly received data
            scroll_index = 0
            last_scroll_time = now

            text_buffer = ""

        else:

            text_buffer = segment

            if scrolling_rows:
                scrolling_rows[-1] = text_buffer
            else:
                scrolling_rows.append(text_buffer)

        last_text_time = now
        clear_screen = False

    # =====================================================
    # SCREEN BLANKING
    # =====================================================
    if screen_blanking:

        if (now - last_text_time) > screen_blanking:

            scrolling_rows.clear()

            text_buffer = ""
            temp_buffer = ""

            scroll_index = 0

            clear_screen = True

            return [], clear_screen

    # =====================================================
    # SCROLLING
    # =====================================================
    total_rows = len(scrolling_rows)
    scroll_delay_enabled = config.get("Onscreen",{}).get("Scrolldelay", False )
    if total_rows > num_rows:

        max_scroll = total_rows - num_rows

        scroll_interval = (
            SCROLL_DELAY_ON
            if scroll_delay_enabled
            else SCROLL_DELAY_OFF
        )

        if (
            scroll_index < max_scroll
            and (now - last_scroll_time) >= scroll_interval
        ):

            scroll_index += 1
            last_scroll_time = now

            print(
                f"[SCROLL] "
                f"index={scroll_index} "
                f"max={max_scroll} "
                f"rows={total_rows}"
            )

    else:
        # No scrolling needed
        scroll_index = 0

    # =====================================================
    # VISIBLE WINDOW
    # =====================================================
    start = scroll_index
    end = start + num_rows

    visible_rows = scrolling_rows[start:end]

    # Optional debug
    # print(
    #     f"[DISPLAY] total={total_rows} "
    #     f"index={scroll_index} "
    #     f"showing={len(visible_rows)}"
    # )

    return visible_rows, clear_screen
# =========================================================
def thai_combining(ch):
    c = ord(ch)
    return (
        c == 0x0E31 or
        0x0E34 <= c <= 0x0E3A or
        0x0E47 <= c <= 0x0E4E
    )

def unicode_display_len(text):
    display_width = 0
    combining_count = 0

    for ch in text:

        if ch == '\r' or ch == '\n':
            continue

        if thai_combining(ch):
            combining_count += 1
            continue

        display_width += 1

    return display_width, combining_count

#number of text to display ecept upper and lower and cut with max_width
def unicode_slice(text, display_width):
    """
    Return a substring whose visible width is display_width.
    Thai combining marks are included in the returned string
    but do not consume display width.
    """

    width = 0
    pos = 0

    while pos < len(text):

        ch = text[pos]

        if ch == '\r' or ch == '\n':
            pos += 1
            continue

        if thai_combining(ch):
            pos += 1
            continue

        if width >= display_width:
            break

        width += 1
        pos += 1

    # Include any trailing Thai marks belonging to the last character
    while pos < len(text) and thai_combining(text[pos]):
        pos += 1

    return text[:pos]

#REGISTER FILTERS
def _process_generic_xy_buffer(new_buffer):
    global temp_buffer, row_width, scrolling_rows
    nulltext = " "
    temp = ""
    state = 0  # 0=waiting for {, 1=reading coords, 2=reading text
    x = None
    y = None
    text_part = ""

    for ch in new_buffer:
        if ch == "{":
            state = 1
            temp = ""
            x = None
            y = None
            text_part = ""
            continue
           
        if ch == "}":
            if x is not None and y is not None:
                while len(scrolling_rows) <= x:
                    scrolling_rows.append("")
        
                # Determine effective leading spaces
                if row_width is not None:
                    max_leading = row_width - len(text_part)
                    effective_y = min(y, max_leading)
                else:
                    effective_y = y
        
                # Prepend leading spaces
                padded_text = (nulltext * effective_y) + text_part
        
                # Ensure total length does not exceed row_width
                if row_width is not None:
                    padded_text = padded_text[:row_width]
        
                scrolling_rows[x] = padded_text
                update_scrolling_text(scrolling_rows[x], force_new_row=False, force_display=True)
        
            state = 0
            continue

        if state == 1:  # reading coords until '='
            if ch == "=":
                try:
                    x_str, y_str = temp.split(",")
                    x = int(x_str)
                    y = int(y_str)
                except ValueError:
                    x = None
                    y = None
                temp = ""
                state = 2
            else:
                temp += ch

        elif state == 2:  # reading text until '}'
            text_part += ch
def _process_generic_buffer(new_buffer):
    global temp_buffer, row_width, scrolling_rows, last_text_time

    # combine leftover partial row with new incoming text
    combined = (temp_buffer or "") + new_buffer

    # if there was a previous partial row, remove it from scrolling_rows
    if temp_buffer and scrolling_rows:
        try:
            scrolling_rows.pop()
        except IndexError:
            pass  # safe fallback if list is empty

    temp_buffer = None  # reset temp buffer before processing

    # remove all \n (we ignore linefeeds)
    combined = combined.replace("\n", "")

    # handle carriage returns by splitting text
    if "\r" in combined:
        parts = combined.split("\r")
        # everything before the last \r is considered complete
        for part in parts[:-1]:
            while len(part) > 0:
                row = part[:row_width]
                update_scrolling_text(row, force_new_row=True, force_display=True)
                part = part[row_width:]
                if config.get("Video", {}).get("Alarm_output", False):
                    check_alarm_trigger(row)           

        # last part (after the final \r) is leftover
        combined = parts[-1]

    # commit all full rows
    while len(combined) >= row_width:
        row = combined[:row_width]
        update_scrolling_text(row, force_new_row=True, force_display=True)
        combined = combined[row_width:] 
        if config.get("Video", {}).get("Alarm_output", False):
            check_alarm_trigger(row)        

    # leftover partial row
    if combined:
        temp_buffer = combined  # store the leftover partial row
        scrolling_rows.append(temp_buffer)  # append to scrolling_rows
        update_scrolling_text(temp_buffer, force_new_row=False, force_display=True)
        if config.get("Video", {}).get("Alarm_output", False):
            check_alarm_trigger(row)        
    else:
        temp_buffer = None
    
    last_text_time = time.time()
    clear_screen = False

"""
def _process_unicode_buffer(new_buffer):

    global temp_buffer, row_width, scrolling_rows

    # STEP 1: combine leftover
    combined = (temp_buffer or "") + new_buffer

    # if there was a previous partial row, remove it from scrolling_rows
    if temp_buffer and scrolling_rows:
        try:
            scrolling_rows.pop()
        except IndexError:
            pass  # safe fallback if list is empty

    temp_buffer = None  # reset temp buffer before processing

    # STEP 3: remove newline
    combined = combined.replace("\n", "")

    # STEP 4: handle \r

    if "\r" in combined:
        parts = combined.split("\r")
        for part in parts[:-1]:
            while unicode_display_len(part) > 0:
                row = unicode_slice(part, row_width)
                update_scrolling_text(row,force_new_row=True, force_display=True )
                part = part[len(row):]
                if config.get("Video", {}).get("Alarm_output", False):
                    check_alarm_trigger(row)
        combined = parts[-1]
   
  
    # STEP 5: check unicode char number 
    while unicode_display_len(combined) >= row_width:
        row = unicode_slice(combined, row_width)
        update_scrolling_text( row,  force_new_row=True, force_display=True  )    
        combined = combined[row] 
        #combined = combined[len(row):]
        if config.get("Video", {}).get("Alarm_output", False):
            check_alarm_trigger(row)

    # leftover partial row
    if combined:
        temp_buffer = combined  # store the leftover partial row
        scrolling_rows.append(temp_buffer)  # append to scrolling_rows
        update_scrolling_text(temp_buffer, force_new_row=False, force_display=True)
        if config.get("Video", {}).get("Alarm_output", False):
            check_alarm_trigger(row)        
    else:
        temp_buffer = None
"""
def _process_unicode_buffer(new_buffer):

    global temp_buffer
    global row_width
    global scrolling_rows
    global last_text_time

    # STEP 1: combine leftover
    combined = (temp_buffer or "") + new_buffer

    # remove previous partial row
    if temp_buffer and scrolling_rows:
        try:
            scrolling_rows.pop()
        except IndexError:
            pass

    temp_buffer = None

    # STEP 2: remove LF
    combined = combined.replace("\n", "")

    # STEP 3: process CR
    if "\r" in combined:

        parts = combined.split("\r")

        for part in parts[:-1]:

            while unicode_display_len(part)[0] > 0:

                row = unicode_slice(part, row_width)

                update_scrolling_text(
                    row,
                    force_new_row=True,
                    force_display=True
                )

                part = part[len(row):]

                if config.get("Video", {}).get("Alarm_output", False):
                    check_alarm_trigger(row)

        combined = parts[-1]

    # STEP 4: wrap full rows
    while unicode_display_len(combined)[0] >= row_width:

        row = unicode_slice(combined, row_width)

        update_scrolling_text(
            row,
            force_new_row=True,
            force_display=True
        )

        combined = combined[len(row):]

        if config.get("Video", {}).get("Alarm_output", False):
            check_alarm_trigger(row)

    # STEP 5: leftover partial row
    if combined:

        temp_buffer = combined

        scrolling_rows.append(temp_buffer)

        update_scrolling_text(
            temp_buffer,
            force_new_row=False,
            force_display=True
        )

        if config.get("Video", {}).get("Alarm_output", False):
            check_alarm_trigger(temp_buffer)

    else:
        temp_buffer = None

    last_text_time = time.time()
    clear_screen = False
#************************************************************************************
PROCESSORS_ASCII = {
    "GENERIC": _process_generic_buffer,
    "GENERIC-NT": _process_generic_buffer,
    "GENERIC-XY": _process_generic_xy_buffer,
    "GENERIC-XY/NT": _process_generic_xy_buffer,
}

PROCESSORS_UNICODE = {
    "GENERIC": _process_unicode_buffer,
    "GENERIC-NT": _process_unicode_buffer,
    "GENERIC-XY": _process_unicode_buffer,
    "GENERIC-XY/NT": _process_unicode_buffer,
}


def handle_incoming_text(raw_text, source=None):
    global register_type, language_now

    if language_now == "ENGLISH":
        processor = PROCESSORS_ASCII.get(register_type)
    else:
        processor = PROCESSORS_UNICODE.get(register_type)

    if processor:
        processor(raw_text)

    if config.get("Communications", {}).get("Miror_Output", False):
        mirror_send(raw_text)
         
# Mirror socket (optional)
mirror_sock = None
mirror_conn = None
mirror_warning_until = 0      # message visible until
mirror_retry_at = 0           # next reconnect attempt

def mirror_connect():
    global mirror_sock, mirror_conn
    if not MIRROR_OUTPUT:
        return
    if USE_TCP:
        try:
            if mirror_sock:
                mirror_sock.close()
            mirror_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            mirror_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            mirror_sock.connect((MIRROR_IP, MIRROR_PORT))
            mirror_conn = mirror_sock
            #print(f"[TCP Mirror] Connected to {MIRROR_IP}:{MIRROR_PORT}")
        except Exception as e:
            #print("[TCP Mirror] connection failed:", e)
            mirror_sock = None
            mirror_conn = None
           
            
    else:
        try:
            if mirror_sock is None:
                mirror_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                #print(f"[UDP Mirror] Ready to send to {MIRROR_IP}:{MIRROR_PORT}")
        except Exception as e:
            print("[UDP Mirror] socket error:", e)

def mirror_send(text):
    global mirror_conn, mirror_sock, mirror_warning_until
    if not MIRROR_OUTPUT:
        return
    try:
        if USE_TCP:
            if mirror_conn is None:
                mirror_connect()
            if mirror_conn:
                mirror_conn.sendall(text.encode('utf-8'))
        else:
            if mirror_sock:
                mirror_sock.sendto(text.encode('utf-8'), (MIRROR_IP, MIRROR_PORT))
    except Exception as e:
        print("[Mirror] send error:", e)
        if USE_TCP and mirror_conn:
            try:
                mirror_conn.close()
            except:
                pass
            mirror_conn = None
            mirror_sock = None
            

#USING TEXT_THREAD TO START EACH RECIEVER
# Network receiver thread (Network TCP or UDP)
"""Original version 
def network_receiver():
    if USE_TCP:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', OVERLAY_PORT))
        sock.listen(1)
        print(f"[TCP] Listening on port {OVERLAY_PORT} for overlay text")
        while True:
            conn, addr = sock.accept()
            print("[TCP] Connection from", addr)
            try:
                while True:
                    data = conn.recv(1024)
                    if not data:
                        break
                    handle_incoming_text(data.decode('utf-8', errors='ignore'))
            except Exception as e:
                print("[TCP] socket error", e)
            finally:
                try:
                    conn.close()
                except: pass
                print("[TCP] client disconnected; waiting for new client")
    else:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', OVERLAY_PORT))
        print(f"[UDP] Listening on port {OVERLAY_PORT} for overlay text")
        while True:
            try:
                data, _ = sock.recvfrom(1024)
                handle_incoming_text(data.decode('utf-8', errors='ignore'))
            except Exception as e:
                print("[UDP] socket error", e)
                break
"""
def network_receiver():
    if USE_TCP:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', OVERLAY_PORT))
        sock.listen(1)
        sock.settimeout(1.0)  # 🔥 IMPORTANT (break blocking accept)

        print(f"[TCP] Listening on port {OVERLAY_PORT}")

        while not serial_stop_event.is_set():
            try:
                conn, addr = sock.accept()
                conn.settimeout(1.0)
                print("[TCP] Connection from", addr)

                while not serial_stop_event.is_set():
                    try:
                        data = conn.recv(1024)
                        if not data:
                            break
                        handle_incoming_text(data.decode('utf-8', errors='ignore'))
                    except socket.timeout:
                        continue

            except socket.timeout:
                continue
            except Exception as e:
                print("[TCP] error:", e)

            finally:
                try:
                    conn.close()
                except:
                    pass

        sock.close()
        print("[TCP] Receiver stopped")

    else:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(('', OVERLAY_PORT))
        sock.settimeout(1.0)  # 🔥 IMPORTANT

        print(f"[UDP] Listening on port {OVERLAY_PORT}")

        while not serial_stop_event.is_set():
            try:
                data, _ = sock.recvfrom(1024)
                handle_incoming_text(data.decode('utf-8', errors='ignore'))
            except socket.timeout:
                continue
            except Exception as e:
                print("[UDP] error:", e)
                break

        sock.close()
        print("[UDP] Receiver stopped")
import traceback

def serial_receiver():

    ser = None

    print("[SERIAL] Receiver started")

    while not serial_stop_event.is_set():

        # =====================================================
        # Open serial port if not connected
        # =====================================================
        if ser is None:

            try:
                ser = open_serial_port()
                print("[SERIAL] Port opened")

            except Exception as e:

                print("[SERIAL] Open failed:", e)

                if serial_stop_event.wait(2):
                    break

                continue

        # =====================================================
        # Read serial data
        # =====================================================
        try:

            data = ser.read(128)

            if data:

                text = data.decode(
                    "utf-8",
                    errors="ignore"
                )

                handle_incoming_text(text)

        except Exception as e:

            print("[SERIAL] Error:", e)

            print("[SERIAL] Traceback:")
            traceback.print_exc()

            # Close failed port
            try:
                ser.close()
                print("[SERIAL] Port closed")
            except Exception:
                pass

            ser = None

            print("[SERIAL] Reconnecting in 2 seconds...")

            if serial_stop_event.wait(2):
                break

    # =========================================================
    # Shutdown
    # =========================================================
    try:
        if ser:
            ser.close()
            print("[SERIAL] Port closed")
    except Exception:
        pass

    print("[SERIAL] Receiver stopped")

def is_serial_mode():
    comm = config.get("Communications", {})
    return comm.get("InputSelection", "").upper() == "SERIAL"
def restart_input_receiver():
    global text_thread

    print("[SYSTEM] Restarting input receiver")
    serial_stop_event.set()

    if text_thread and text_thread.is_alive():
        text_thread.join(timeout=2)

    time.sleep(0.2)  # IMPORTANT: let OS release port
    serial_stop_event.clear()   
    start_input_receiver()

def start_input_receiver():
    global text_thread

    comm = config.get("Communications", {})
    input_mode = comm.get("InputSelection", "NETWORK").upper()

    if input_mode == "SERIAL":
        print("[SYSTEM] Using SERIAL input mode")
        target = serial_receiver
    else:
        print("[SYSTEM] Using NETWORK input mode")
        target = network_receiver

    text_thread = threading.Thread( target=target,daemon=True )
    text_thread.start()
    print("[SYSTEM] Input thread started")

# ---------- Frame producer (single capture + processing) ----------
frame_lock = threading.Lock()
shared_frame = None
last_capture_time = 0
frame_id = 0
stream_last = 0
stream_interval = 1.0 / FPS
running = True

#subprocess IP static
NM_PROFILE = "Wired connection 3"   # ← fixed for your system
def set_static_ip(ip, gateway, subnet="24"):
    try:
        subprocess.run([
            "nmcli", "connection", "modify", NM_PROFILE,
            "ipv4.addresses", f"{ip}/{subnet}",
            "ipv4.gateway", gateway,
            "ipv4.method", "manual"
        ], check=True)

        #subprocess.run(["nmcli", "connection", "down", NM_PROFILE], check=True)
        subprocess.run(["nmcli", "connection", "up", NM_PROFILE], check=True)

        print(f"[NETWORK] Static IP set to {ip}")
        return True

    except Exception as e:
        print("[NETWORK ERROR]", e)
        return False

#system restart 

global gst_thread
gst_thread = None

def free_port(port):
    os.system(f"fuser -k {port}/tcp")
def init_network_from_config():
    global config

    # KEEP ORIGINAL POSITION
    stop_capture_thread()


    with config_lock:
        with open(CONFIG_FILE) as f:
            cfg = yaml.safe_load(f) or {}

        comms = cfg.get("Communications", {})
        system = cfg.setdefault("System", {})

        cfg_ip = comms.get("IP")
        cfg_gw = comms.get("Gateway")
        cfg_subnet = comms.get("Subnet")

        if cfg_ip and cfg_gw and cfg_subnet:

            try:
                cidr = subnet_to_cidr(cfg_subnet)

                # active connection
                active = subprocess.check_output(
                    "nmcli -t -f NAME connection show --active",
                    shell=True
                ).decode().strip().split("\n")[0]

                # current SYSTEM settings
                current_ip_info = subprocess.check_output(
                    f"nmcli -g IP4.ADDRESS connection show '{active}' | head -n1",
                    shell=True
                ).decode().strip()

                current_gw = subprocess.check_output(
                    f"nmcli -g IP4.GATEWAY connection show '{active}'",
                    shell=True
                ).decode().strip()

                current_ip = ""
                current_subnet = ""

                if "/" in current_ip_info:
                    current_ip, current_cidr = current_ip_info.split("/")
                    current_subnet = cidr_to_subnet(int(current_cidr))

                print(f"[INIT] System IP      : {current_ip}")
                print(f"[INIT] System Gateway : {current_gw}")
                print(f"[INIT] System Subnet  : {current_subnet}")

                print(f"[INIT] Config IP      : {cfg_ip}")
                print(f"[INIT] Config Gateway : {cfg_gw}")
                print(f"[INIT] Config Subnet  : {cfg_subnet}")

                # compare SYSTEM vs CONFIG
                network_changed = (
                    current_ip != cfg_ip or
                    current_gw != cfg_gw or
                    current_subnet != cfg_subnet
                )

                if network_changed:

                    print("[INIT] Applying saved network config")

                    os.system(
                        f"sudo -n nmcli connection modify '{active}' "
                        f"ipv4.addresses {cfg_ip}/{cidr} "
                        f"ipv4.gateway {cfg_gw} "
                        f"ipv4.method manual"
                    )

                    print("[INIT] Waiting for network settle in1s")
                    time.sleep(1)

                    os.system(
                        f"sudo -n nmcli connection up '{active}'"
                    )

                    print("[INIT] Starting for new network in 5s...")
                    time.sleep(5)

                    print("[INIT] Network updated")

                else:
                    print("[INIT] Network already correct")

            except Exception as e:
                print("[INIT ERROR]", e)

        # KEEP ORIGINAL LOGIC
        system["ApplyNetwork"] = False
        system["RestartHTTP"] = False
        system["RestartStream"] = False
        system["RestartCapture"] = False

        with open(CONFIG_FILE, "w") as f:
            yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)

        config = cfg

    # KEEP ORIGINAL POSITION    
    start_capture_thread()              #reload_config
  

def subnet_to_cidr(mask):
    return sum(bin(int(x)).count('1') for x in mask.split('.'))
def initialize_system_flags():
    with config_lock:
        with open(CONFIG_FILE) as f:
            cfg = yaml.safe_load(f) or {}

        system = cfg.setdefault("System", {})

        # ✅ Clear one-shot flags
        system["RestartStream"] = False
        system["RestartHTTP"] = False
        system["RestartCapture"] = False
        system["ApplyNetwork"] = False

        # OPTIONAL: clear stale action
        system["LastAction"] = "BOOT"

        with open(CONFIG_FILE, "w") as f:
            yaml.dump(cfg, f, sort_keys=False)

    print("[SYSTEM] Flags initialized on boot")
def initialize_runtime_config():
    global config, last_resolution, last_text_size, last_register 
    global FPS

    with open(CONFIG_FILE) as f:
        config = yaml.safe_load(f) or copy.deepcopy(DEFAULT_CONFIG)

    # -------- Onscreen --------
    onscreen = config.get("Onscreen", {})
    apply_onscreen_config(onscreen)

    last_text_size = onscreen.get("TextSize")
    last_register = onscreen.get("Register")

    # -------- Video --------
    video = config.get("Video", {})
    #suppressed due to RKISP
    apply_camera_controls(video)
    apply_video_pipeline(video)


    last_resolution = video.get("Videoresolution")
    FPS = video.get("FPS", FPS)

    print("[INIT] Runtime config applied")

def system_worker():

    global running

    print("[SYSTEM] Worker started")

    while True:

        time.sleep(1)

        # =====================================================
        # 🔥 ALWAYS USE LIVE CONFIG (NOT FILE DIRECTLY)
        # =====================================================

        with config_lock:
            cfg = globals().get("config", {})
            system = cfg.get("System", {})

            reboot = system.get("RebootRequired", False)
            restart_stream = system.get("RestartStream", False)
            restart_http = system.get("RestartHTTP", False)
            restart_capture = system.get("RestartCapture", False)
            apply_network = system.get("ApplyNetwork", False)

        print(
            f"[SYSTEM] reboot={reboot} "
            f"net={apply_network} "
            f"stream={restart_stream} "
            f"http={restart_http} "
            f"capture={restart_capture}"
        )

        # =====================================================
        # 🔥 REBOOT (HIGHEST PRIORITY)
        # =====================================================

        if reboot:

            print("[SYSTEM] REBOOT REQUESTED")

            stop_capture_thread()
            stop_services()

            with config_lock:
                system["RebootRequired"] = False
                system["RestartStream"] = False
                system["RestartHTTP"] = False
                system["RestartCapture"] = False
                system["ApplyNetwork"] = False

                with open(CONFIG_FILE, "w") as f:
                    yaml.dump(cfg, f)

            os.system("sudo reboot")
            return

        # =====================================================
        # 🔥 NETWORK APPLY (SEPARATE FLOW)
        # =====================================================

        if apply_network:

            print("[SYSTEM] APPLY NETWORK")

            stop_capture_thread()
            stop_services()

            with config_lock:
                comms = cfg.get("Communications", {})

                ip = comms.get("IP")
                gw = comms.get("Gateway")
                subnet = comms.get("Subnet")
                cidr = subnet_to_cidr(subnet)

            if ip and gw:

                active = subprocess.check_output(
                    "nmcli -t -f NAME connection show --active",
                    shell=True
                ).decode().strip().split("\n")[0]

                os.system(
                    f"sudo nmcli connection modify '{active}' "
                    f"ipv4.addresses {ip}/{cidr} "
                    f"ipv4.gateway {gw} "
                    f"ipv4.method manual"
                )

                os.system(f"sudo nmcli connection up '{active}'")

            time.sleep(1)


            start_capture_thread()

            restart_all_after_network()

            with config_lock:
                system["ApplyNetwork"] = False
                system["RestartHTTP"] = True
                system["ReloadUI"] = True

        # =====================================================
        # 🔥 CAPTURE RESTART
        # =====================================================
        if restart_capture:
            print("[SYSTEM-WORKER] CAPTURE RESTART")
            restart_capture_thread()

        # =====================================================
        # 🔥 STREAM RESTART
        # =====================================================
        if restart_stream:
            print("[SYSTEM-WORKER] RTSP RESTART")
            #restart_rtsp_pipeline()
            update_rtsp_caps_only()

        # =====================================================
        # 🔥 HTTP RESTART
        # =====================================================
        if restart_http:
            print("[SYSTEM-WORKER] HTTP RESTART")
            restart_http_server()
            restart_app()


        # =====================================================
        # 🔥 CLEAR FLAGS (SAFE SINGLE PLACE)
        # =====================================================

        if any([restart_stream, restart_http, restart_capture]):

            with config_lock:

                system["RestartStream"] = False
                system["RestartHTTP"] = False
                system["RestartCapture"] = False

                with open(CONFIG_FILE, "w") as f:
                    yaml.dump(cfg, f)
def restart_all_after_network():
    global gst_thread

    print("[SYSTEM] Applying network + restarting services...")

    stop_services()


    # Wait until camera device is ready  
    if wait_for_camera_ready(cap):
        start_capture_thread()
    else:
        print(f"[CAPTURE] Camera not ready, capture skipped")

    # Restart RTSP if needed
    with config_lock:
        comms = config.get("Communications", {})
        mode = comms.get("Streammode", "MJPEG").upper()
    if mode == "RTSP":
        restart_rtsp_pipeline()

    # Restart HTTP by execv
    restart_http_server()
def stop_services():
    global gst_thread, running, capture_thread

    print("[SYSTEM] Stopping all services...")

    # Stop capture thread
    stop_capture_thread()

    # Stop RTSP if running
    if gst_thread is not None:
        try:
            print("[RTSP] Stopping existing RTSP pipeline...")
            gst_thread.stop()
            gst_thread.join(timeout=2.0)
        except Exception as e:
            print("[RTSP ERROR] Stop failed:", e)
        gst_thread = None

    # Stop HTTP server by exiting Python process
    # (Only do this if you are going to restart it immediately)
    print("[HTTP] HTTP server will be restarted automatically if needed")                    
def restart_app():
    stop_capture_thread()   # 🔥 THIS IS THE KEY
    print("[SYSTEM] Restarting full application...")
    os.execv(sys.executable, ['python3'] + sys.argv)
def stop_capture_thread():

    global running, capture_thread, cap

    print("[CAPTURE] Stopping capture thread...")

    running = False

    if capture_thread and capture_thread.is_alive():

        print("[CAPTURE] Waiting for thread to stop...")

        capture_thread.join(timeout=3.0)

    # release camera safely
    if cap is not None:

        try:

            cap.release()

            print("[CAPTURE] Camera released")

        except Exception as e:

            print("[CAPTURE] Release error:", e)

        cap = None

    time.sleep(1.5)  # RKISP needs settle time
def start_capture_thread():

    global running, capture_thread, cap

    print("[CAPTURE] Starting thread...")

    # =====================================================
    # 1. RELEASE OLD CAMERA FIRST
    # =====================================================

    if cap is not None:

        cap.release()

        cap = None

    time.sleep(1.0)

    # =====================================================
    # 2. RELOAD CONFIG
    # =====================================================

    reload_derived_config()

    # =====================================================
    # 3. FORCE CAMERA INIT (IMPORTANT FIX)
    # =====================================================

    init_camera()

    # =====================================================
    # 4. WAIT CAMERA READY
    # =====================================================

    wait_for_camera_ready(cap)

    # =====================================================
    # 5. START THREAD
    # =====================================================

    running = True

    capture_thread = threading.Thread(
        target=frame_capture_loop,
        daemon=True
    )

    mirror_connect();

    capture_thread.start()

    print("[CAPTURE] Started")
    print("[CAPTURE] Restart complete")
def restart_capture_thread():
    print("[CAPTURE] Restart requested...")

    stop_capture_thread()
    time.sleep(1)   # 🔥 allow hardware to settle
    start_capture_thread()

    print("[CAPTURE] Restart complete")
def restart_http_server():
    print("[SYSTEM] Restarting HTTP server...")

    try:
        # Give response time to return to client
        time.sleep(0.5)

        python = sys.executable

        print(f"[SYSTEM] Re-executing: {python} {' '.join(sys.argv)}")

        os.execv(python, [python] + sys.argv)

    except Exception as e:
        print("[ERROR] Failed to restart HTTP:", e)

def restart_rtsp_pipeline():
    global gst_thread

    print("[RTSP] Restart requested")

    # 🔁 Reload latest config
    with config_lock:
        comms = config.get("Communications", {})
        video = config.get("Video", {})

        host_ip = comms.get("IP", "0.0.0.0")
        port = comms.get("Streamport", 554)

        width = video.get("Width", CAP_WIDTH)
        height = video.get("Height", CAP_HEIGHT)
        fps = video.get("FPS", FPS)

    # 🔴 Stop existing RTSP
    if gst_thread is not None:
        try:
            print("[RTSP] Stopping existing RTSP pipeline...")
            gst_thread.stop()
            gst_thread.join(timeout=2.0)
        except Exception as e:
            print("[RTSP ERROR] Stop failed:", e)

        gst_thread = None

    # 🟢 Always start RTSP
    try:
        print(f"[RTSP] Starting RTSP at rtsp://{host_ip}:{port}/live")

        gst_thread = GstRtspServerThread(
            host_ip, port, width, height, fps
        )
        gst_thread.start()

        print("[RTSP] Restart complete")

    except Exception as e:
        print("[RTSP ERROR] Start failed:", e)
class GstRtspServerThread(threading.Thread):
    def __init__(self, host, port, width, height, fps):
        super().__init__(daemon=True)
        self.host = host
        self.port = port
        self.width = width
        self.height = height
        self.fps = fps
        self.loop = None

    def run(self):
        self.loop = GLib.MainLoop()

        self.server = GstRtspServer.RTSPServer()
        self.server.set_address(self.host)
        self.server.set_service(str(self.port))

        factory = AppSrcFactory(self.width, self.height, self.fps)
        mount_points = self.server.get_mount_points()
        mount_points.add_factory("/stream", factory)

        self.server.attach(None)

        print(f"[RTSP] Streaming at rtsp://{self.host}:{self.port}/stream")

        try:
            self.loop.run()
        except:
            pass

    def stop(self):
        if self.loop:
            print("[RTSP] Stopping loop...")
            self.loop.quit()

# need to add Hue and Sharpness
def adjust_bcs(img, brightness, contrast, saturation, hue, sharpness):

    img = img.astype(np.float32)

    # ----- Brightness / Contrast -----
    beta = (brightness - 50) * 2.55
    alpha = contrast / 50.0

    img = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)

    # ----- Saturation / Hue -----
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.float32)

    # Saturation
    hsv[..., 1] *= saturation / 50.0
    hsv[..., 1] = np.clip(hsv[..., 1], 0, 255)

    # Hue
    # OpenCV hue range = 0-179
    hue_shift = int((hue - 50) * 1.8)
    hsv[..., 0] = (hsv[..., 0] + hue_shift) % 180

    img = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)

    # ----- Sharpness -----
    if sharpness != 50:

        amount = (sharpness - 50) / 50.0

        blur = cv2.GaussianBlur(img, (0, 0), 3)

        img = cv2.addWeighted(
            img,
            1.0 + amount,
            blur,
            -amount,
            0
        )

    return img
# --------------------------------------------------
def calculate_line_height():
    global language_now

    padding_y = 2

    font_obj = FONT_EN if language_now == "ENGLISH" else FONT_UNI

    bbox = font_obj.getbbox("HgÅgjЙภาษาไทย中文")
    text_height = bbox[3] - bbox[1]

    return text_height + (padding_y * 2)

def get_max_char_width(font_obj):
    test_chars = (
        "W"
        "Ｍ"      # Full-width Latin
        "國"      # Chinese
        "漢"
        "あ"      # Japanese
        "가"      # Korean
        "Й"      # Cyrillic
        "ฬ"      # Thai
    )

    max_width = 0

    for ch in test_chars:
        bbox = font_obj.getbbox(ch)
        width = bbox[2] - bbox[0]
        max_width = max(max_width, width)

    return max_width

def update_font_metrics():
    global language_now
    global text_width, text_height, line_height, spacing_line

    padding_y = 4

    font_obj = FONT_EN if language_now == "ENGLISH" else FONT_UNI

    max_char_width = get_max_char_width(font_obj)

    row_width = int(config["Onscreen"].get("Displaywidth", 60))

    text_width = max_char_width * row_width

    bbox = font_obj.getbbox("HgÅЙภาษาไทย中文")
    text_height = bbox[3] - bbox[1]

    #line_spacing = 0
    if language_now in ("ARABIC"):
        padding_y = padding_y + spacing_line

    line_height = text_height + (padding_y * 2)     

# Draw Unicode text mulitlanguage
def draw_unicode_text(frame, text, position):
    global y_offset

    img = Image.fromarray(frame)
    draw = ImageDraw.Draw(img)

    x, y = position
    current = ""
    current_type = None

    def flush_run(run, run_type, x_pos):
        if not run:
            return x_pos

        font = FONT_EN if run_type == "english" else FONT_UNI  
        draw.text(
            (x_pos, y - int(line_height * 0.75) + y_offset + y_offset),
            run,
            font=font,
            fill=(255, 255, 255)
        )

        return x_pos + draw.textlength(run, font=font)

    for ch in text:

        ch_type = "english" if ord(ch) < 128 else "unicode"

        if ch_type != current_type:
            x = flush_run(current, current_type, x)
            current = ch
            current_type = ch_type
        else:
            current += ch

    flush_run(current, current_type, x)

    frame[:] = np.array(img)
    return frame

def draw_text(img, x, y, text, full_width=False):
    global font, text_size, font_scale, font_thickness, line_height, num_rows
    # Draw background first
    draw_background_line(img, y, text=text, x=x, full_width=full_width)

    # Draw text with shadow
    text_y = y - int(line_height * 0.25)
    draw_text_with_shadow(img, text, (x, text_y))

#notes: 1. Testing overlap black ground using gray scale only will see the overlapped 
#       2. Using "W" to calculate max leght of each row    
def draw_background_line(img, y, text=" ", x=None, full_width=False):
    global font, font_scale, font_thickness
    global y_offset, text_height, row_width
  
    y = y + y_offset
    if background_alpha == 0.0:
        return

    padding_x = 4
    padding_y = 6

    x_pos = base_x if x is None else x   
    # Measure text
    if full_width:
        (text_width, text_height), baseline = cv2.getTextSize(
            text, font, font_scale, font_thickness
        )
    else:
        (text_width, text_height), baseline = cv2.getTextSize(
            "W" * row_width, font, font_scale, font_thickness
        )

    width = text_width + 2 * padding_x

    # ✅ FIXED vertical alignment

    top_left = ( x_pos - padding_x,y - line_height + padding_y )

    #-1 to prevent overlap
    bottom_right = ( x_pos + width, y + padding_y-1)
    
    overlay = img.copy()
    cv2.rectangle(overlay, top_left, bottom_right, background_color, -1)
    cv2.addWeighted(overlay, background_alpha, img, 1 - background_alpha, 0, img)

def draw_text_with_shadow(img, text, org):
    global font, text_size, font_scale, font_thickness, line_height, num_rows
    x,y = org
    ox,oy = shadow_offset
    cv2.putText(img, text, (x+ox, y+oy), font, font_scale, shadow_color, font_thickness, cv2.LINE_AA)
    cv2.putText(img, text, (x, y), font, font_scale, font_color, font_thickness, cv2.LINE_AA)

##################################################CAPTURE THREA #####################################################################
capture_thread = None
capture_running = False

def frame_capture_loop():
    global cap, shared_frame, frame_lock, frame_count, running, clear_screen
    global font, font_scale, font_thickness
    global line_height, mirror_conn, mirror_warning_until, mirror_retry_at
    global language_now, num_rows, y_offset
    global text_width, text_height  

    print("[CAPTURE] Thread started")

    # Calculate initial metrics
    update_font_metrics()

    current_language = language_now

    last_time = 0.0

    if cap is None or not cap.isOpened():
        init_camera()

    try:
        while running:

            # ================================================
            # Update metrics if language changed
            # ================================================
            if current_language != language_now:
                current_language = language_now
                update_font_metrics()

                print(
                    f"[FONT] Language={language_now} "
                    f"Width={text_width} "
                    f"Height={text_height} "
                    f"LineHeight={line_height}"
                )

            # ================================================
            # FPS CONTROL
            # ================================================
            target_fps = get_target_fps()
            frame_interval = 1.0 / target_fps

            now = time.time()

            if last_time != 0:
                elapsed = now - last_time
                if elapsed < frame_interval:
                    time.sleep(0.001)
                    continue

            last_time = now

            # ================================================
            # READ FRAME
            # ================================================
            ret, frame = cap.read()

            if not ret:
                time.sleep(0.01)
                continue

            frame = cv2.resize(frame, (CAP_WIDTH, CAP_HEIGHT))

            frame = adjust_bcs(
                frame,
                brightness_pct,
                contrast_pct,
                saturation_pct,
                hue_pct,
                sharpness_pct
            )

            y_pos = base_y

            # ================================================
            # TIMESTAMP
            # ================================================
            if td_enabled:
                ts = get_formatted_timestamp()

                draw_background_line(
                    frame,
                    y_pos,
                    text=ts,
                    x=base_x
                )

                draw_unicode_text(
                    frame,
                    ts,
                    (base_x, y_pos)
                )

                y_pos += line_height

            # ================================================
            # TITLE
            # ================================================
            if titler_enabled:

                draw_background_line(
                    frame,
                    y_pos,
                    text=camera_title_text,
                    x=base_x
                )

                draw_unicode_text(
                    frame,
                    camera_title_text,
                    (base_x, y_pos)
                )

                y_pos += line_height

            # ================================================
            # MIRROR STATUS
            # ================================================
            if config.get("Communications", {}).get("Miror_Output", False):

                if mirror_conn is None and now >= mirror_retry_at:

                    mirror_connect()

                    if mirror_conn is None:
                        mirror_warning_until = now + 10
                        mirror_retry_at = now + 20

                if clear_screen and now < mirror_warning_until:

                    draw_background_line(
                        frame,
                        y_pos,
                        text=mirror_warning_text,
                        x=base_x
                    )

                    draw_unicode_text(
                        frame,
                        mirror_warning_text,
                        (base_x, y_pos)
                    )

                    y_pos += line_height
             
            # ================================================
            # SCROLLING TEXT
            # ================================================
            if register_type in ("GENERIC", "GENERIC-NT"):
                rows, clear_screen = update_scrolling_text()
                if text_display_enabled and rows:
                    for i, row in enumerate(rows):
                        y_row = y_pos + (i * line_height)
                        text_str = str(row)
                        draw_background_line( frame, y_row, text=text_str,x=base_x )
                        if text_str.strip():
                            if language_now == "ENGLISH":
                                draw_text_with_shadow(frame, text_str,(base_x, y_row) )

                            else:
                                draw_unicode_text( frame, text=text_str, position=(base_x, y_row))

            # ================================================
            # ALARM
            # ================================================
            y_pos = draw_alarm(frame, y_pos, None, None)

            # ================================================
            # SHARE FRAME
            # ================================================
            with frame_lock:
                shared_frame = frame.copy()

            frame_count += 1

            if frame_count % 60 == 0:
                print(
                    f"[CAPTURE] Alive "
                    f"Frame={frame_count} "
                    f"FPS={target_fps}"
                )

    finally:

        print("[CAPTURE] Releasing camera...")

        if cap:
            cap.release()

        print("[CAPTURE] Thread stopped")

#fixing capture thread to restart for text setups
overlay_lock = threading.Lock()
overlay_state = {
    "font": cv2.FONT_HERSHEY_SIMPLEX,

    "font_scale": 0.5,
    "font_thickness": 2,

    "base_x": 14,
    "base_y": 14,

    "row_width": 60,
    "max_rows": 42,

    "font_color": (255, 255, 255),
    "background_color": (0, 0, 0),
    "background_alpha": 0.6,

    "shadow_color": (0, 0, 0),
    "shadow_offset": (2, 2),
}
def update_overlay(**kwargs):
    with overlay_lock:
        overlay_state.update(kwargs)
def apply_onscreen_config(onscreen):

    global camera_title_text, row_width, max_rows
    global td_enabled, titler_enabled, text_display_enabled

    base_x = onscreen.get("Horizontal_Pos", 50)
    base_y = onscreen.get("Vertical_Pos", 50)
    row_width = onscreen.get("Displaywidth", 50)
    max_rows = onscreen.get("Displayline", 10)

    text_color = parse_color(
        onscreen.get("Textcolor", "white"),
        onscreen.get("Textforeground", 255)
    )
    bg_color = parse_color(
        onscreen.get("Backgroundcolor", "black"),
        onscreen.get("Textbackground", 60)
    )

    # ✅ ENABLE FLAGS (LIVE UPDATE)
    td_enabled = bool(onscreen.get("TDdisplay", True))
    titler_enabled = bool(onscreen.get("Titlerdisplay", ""))
    text_display_enabled = bool(onscreen.get("TextDisplay", True))

    # ✅ TITLE TEXT
    raw_title = str(onscreen.get("Titler", "")).strip()

    if raw_title == "":
        titler_enabled = False   # force OFF if empty
    # else: leave titler_enabled unchanged
    camera_title_text = raw_title

    video_res = config.get("Video", {}).get("Videoresolution", "720P")

    font_scale = compute_font_scale(video_res, base_scale=0.5)
    font_scale *= max(0.5, onscreen.get("TextSize", 1) / 2)

    font_thickness = max(1, int(font_scale * 2))


    update_overlay(
        base_x=base_x,
        base_y=base_y,
        row_width=row_width,
        max_rows=max_rows,
        #font_scale=max(0.25, onscreen.get("TextSize", 1) * 0.25),  
        font_scale=font_scale,
        font_thickness=max(1, onscreen.get("Bold", 1)),
        font_color=text_color,
        background_color=bg_color,
        background_alpha=onscreen.get("Screenblanking", 60) / 100.0
    )
def apply_video_pipeline(video):
    global brightness_pct, contrast_pct, saturation_pct, hue_pct, sharpness_pct

    brightness_pct = int(video.get("brightness", 50))
    contrast_pct   = int(video.get("contrast", 50))
    saturation_pct = int(video.get("saturation", 50))
    hue_pct = int(video.get("hue", 50))
    sharpness_pct   = int(video.get("sharpness", 50))


    print(f"[PIPELINE] BCS = {brightness_pct}, {contrast_pct}, {saturation_pct},, {hue_pct},{sharpness_pct}")
def apply_overlay_network_config(communication):

    global OVERLAY_PORT
    global USE_TCP
    global MIRROR_OUTPUT
    global MIRROR_IP
    global MIRROR_PORT
    global mirror_warning_text

    OVERLAY_PORT = int(communication.get("Overlayport", 9100))
    USE_TCP = communication.get("Textprotocol", "TCP").upper() == "TCP"

    MIRROR_OUTPUT = communication.get("Miror_Output", False)
    MIRROR_IP = communication.get("TargetIP", host_ip)
    MIRROR_PORT = int(communication.get("Mirorport", 9101))

    mirror_warning_text = (
        f"WARNING: Mirror {MIRROR_IP}:{MIRROR_PORT} not available"
    )
def apply_serial_control(communication):
    global baud, databits,stopbits,parity 

    baud = int(communication.get("BaudRate", 9600))
    databits = str(communication.get("DataBits", 8)).strip()
    stopbits = str(communication.get("StopBits", 1)).strip()
    parity = str(communication.get("Parity", "NONE")).upper()
   
def apply_default_camera_config(video, config):
    v = config["Video"]

    #video["exposure"] = v["exposure"]
    #video["analogue_gain"] = v["analogue_gain"]

    #video["auto_exposure"] = 0 if not v["AE"] else 1
    #video["agc"] = v["AGC"]

    video["brightness"] = v["brightness"]
    video["contrast"] = v["contrast"]
    video["saturation"] = v["saturation"]

    video["vertical_flip"] = v["Vertical_flip"]
    video["horizontal_flip"] = v["Horizontal_flip"]

    #suppressed due to RKISP
    apply_camera_controls(video)

    print("[CAMERA] Default config applied (MANUAL BASELINE READY)")

def apply_camera_controls(video):
    #exposure = int(video.get("exposure", 1050))
    #gain     = int(video.get("analogue_gain", 100))

    hflip = int(video.get("Horizontal_flip", 0))
    vflip = int(video.get("Vertical_flip", 0))

    # Clamp to sensor limits
    #exposure = max(4, min(2242, exposure))
    #gain     = max(0, min(240, gain))

    #set_ctrl("exposure", exposure)
    #set_ctrl("analogue_gain", gain)
    set_ctrl("horizontal_flip", hflip)
    set_ctrl("vertical_flip", vflip)
    print("[CAMERA] Applied V4L2 controls")

def update_alarm_system(enabled, state, duration):
    global alarm_enabled, alarm_state, alarm_duration

    alarm_enabled = enabled
    alarm_state = state
    alarm_duration = duration

    print(f"[ALARM] Enabled={enabled}, State={state}, Duration={duration}")
# ---------- RTSP via GStreamer (appsrc) ----------
def restart_rtsp_pipeline():

    global gst_thread

    print("[RTSP] Restart requested")

    with config_lock:

        comm = config.get("Communications", {})
        video = config.get("Video", {})

        host_ip = comm.get("IP", "0.0.0.0")
        port = comm.get("Streamport", 554)

        res_name = video.get("Videoresolution", "1080P")
        fps_value = video.get("Framerate", "25FPS")

    width, height = get_resolution(res_name)
    fps = parse_fps_safe(fps_value)

    if gst_thread is not None:

        try:
            gst_thread.stop()
            gst_thread.join(timeout=2.0)

        except Exception as e:
            print("[RTSP ERROR]", e)

        gst_thread = None

    try:

        gst_thread = GstRtspServerThread(
            host_ip,
            port,
            width,
            height,
            fps
        )

        gst_thread.start()

        print(f"[RTSP] rtsp://{host_ip}:{port}/stream")

    except Exception as e:

        print("[RTSP ERROR]", e)

def update_rtsp_caps_only():

    with config_lock:
        video = config.get("Video", {})

        res = video.get("Videoresolution", "1080P")
        fps = parse_fps_safe(video.get("Framerate", "25FPS"))

    width, height = get_resolution(res)

    print(f"[RTSP UPDATE] {width}x{height}@{fps}")

# =========================================================
# RTSP FACTORY
# =========================================================

class AppSrcFactory(GstRtspServer.RTSPMediaFactory):

    def __init__(self, width, height, fps):

        super().__init__()

        self.width = width
        self.height = height
        self.fps = fps

        self.number_frames = 0
        self.duration = 1 / fps * Gst.SECOND

        self.set_shared(True)

        # =====================================================
        # RK3588 MPP HARDWARE ENCODER
        # =====================================================

        self.launch = (
            'appsrc name=source is-live=true block=true format=time '
            '! queue '
            '! videoconvert '
            '! video/x-raw,format=NV12 '
            '! mpph264enc '
            '! h264parse '
            '! rtph264pay config-interval=1 name=pay0 pt=96'
        )

    # =========================================================
    # CREATE PIPELINE
    # =========================================================

    def do_create_element(self, url):

        pipeline = Gst.parse_launch(self.launch)

        self.appsrc = pipeline.get_by_name("source")

        caps = Gst.Caps.from_string(
            f"video/x-raw,"
            f"format=BGR,"
            f"width={self.width},"
            f"height={self.height},"
            f"framerate={self.fps}/1"
        )

        self.appsrc.set_property("caps", caps)

        self.appsrc.set_property(
            "format",
            Gst.Format.TIME
        )

        self.appsrc.connect(
            "need-data",
            self.on_need_data
        )

        with frame_lock:
            if shared_frame is None:
                print("[RTSP] no frame yet")
            else:
                print(f"[RTSP] frame={shared_frame.shape}")

        return pipeline

    # =========================================================
    # PUSH FRAME
    # =========================================================

    def on_need_data(self, src, length):

        global shared_frame, frame_lock

        with frame_lock:

            if shared_frame is None:
                return

            frame = shared_frame.copy()
            frame = cv2.resize(
                frame,
                (self.width, self.height)
            )
        data = frame.tobytes()

        buf = Gst.Buffer.new_allocate(
            None,
            len(data),
            None
        )

        buf.fill(0, data)

        # =====================================================
        # TIMESTAMP
        # =====================================================

        timestamp = self.number_frames * self.duration

        buf.pts = buf.dts = int(timestamp)

        buf.duration = int(self.duration)

        self.number_frames += 1

        retval = src.emit("push-buffer", buf)

        if retval != Gst.FlowReturn.OK:
            print("[RTSP] push-buffer failed:", retval)


# =========================================================
# RTSP SERVER THREAD
# =========================================================
class GstRtspServerThread(threading.Thread):

    def __init__(self, host, port, width, height, fps):

        super().__init__(daemon=True)

        self.host = host
        self.port = port
        self.width = width
        self.height = height
        self.fps = fps

        self.loop = None

    def run(self):

        self.loop = GLib.MainLoop()

        self.server = GstRtspServer.RTSPServer()

        self.server.set_address(self.host)
        self.server.set_service(str(self.port))

        factory = AppSrcFactory(
            self.width,
            self.height,
            self.fps
        )

        factory.set_shared(True)

        self.server.get_mount_points().add_factory(
            "/stream",
            factory
        )

        self.server.attach(None)

        print(f"[RTSP] Streaming rtsp://{self.host}:{self.port}/stream")

        try:
            self.loop.run()

        except:
            pass

    def stop(self):

        if self.loop:
            self.loop.quit()


# MJPEG stays the same
def mjpeg_generator():
    global shared_frame, stream_last, stream_interval

    stream_last = time.time()

    while True:

        now = time.time()

        # ⛔ FPS LIMIT (clean throttle)
        if now - stream_last < stream_interval:
            time.sleep(0.001)   # prevents CPU spin
            continue

        with frame_lock:
            frame = shared_frame

        if frame is None:
            time.sleep(0.01)
            continue

        ok, jpeg = cv2.imencode(
            '.jpg',
            frame,
            [int(cv2.IMWRITE_JPEG_QUALITY), 85]  # lower = faster + less traffic
        )

        if not ok:
            continue

        stream_last = now

        yield (
            b'--frame\r\n'
            b'Content-Type: image/jpeg\r\n\r\n' +
            jpeg.tobytes() +
            b'\r\n'
        )
# ---------- Flask app + routes ----------
app = Flask(__name__, static_folder='static', template_folder='templates')

if not os.path.exists('templates'):
    os.makedirs('templates', exist_ok=True)
index_path = os.path.join('templates','index.html')
if not os.path.exists(index_path):
    with open(index_path,'w') as fh:
        fh.write(INDEX_HTML)


#these app route layer for front end to run it that can effect to backend
@app.route('/')
def index():
    return render_template('index.html', host_ip=host_ip, stream_port=STREAM_PORT, stream_mode=config["Communications"]["Streammode"].upper())

@app.route('/video_feed')
def video_feed():
    return Response(
        mjpeg_generator(),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )

@app.route('/apply_network_settings', methods=['POST'])
def apply_network_settings():
    ip = config["Communications"]["IP"]
    subnet = config["Communications"]["Subnet"]
    gateway = config["Communications"]["Gateway"]
    interface = config["Communications"].get("interface", "eth0")
    try:
        result = subprocess.run(['sudo','./set_network.py',ip,subnet,gateway,interface], capture_output=True, text=True, check=True)
        return jsonify({"status":"success","output":result.stdout}), 200
    except subprocess.CalledProcessError as e:
        return jsonify({"status":"error","error":e.stderr}), 500

#new load_config & save_config with Support Alarm Number saving
@app.route('/load-config/<tab_name>', methods=['GET'])
def load_config(tab_name):
    global last_text_size, last_register, last_resolution

    with config_lock:   # ✅ FIX: lock added
        with open(CONFIG_FILE) as f:
            cfg = yaml.safe_load(f) or copy.deepcopy(DEFAULT_CONFIG)

    video = cfg.get("Video", {})
    current_res = video.get("Videoresolution", "720P")

    # -------- existing logic (safe) --------
    if tab_name == "Onscreen":
        onscreen = cfg.get("Onscreen", {})
        last_text_size = onscreen.get("TextSize", 2)
        last_register = onscreen.get("Register", "")
        last_resolution = current_res

    if tab_name == "Communications":
        comms = cfg.get("Communications", {})
        for key in ["BaudRate", "DataBits", "StopBits"]:
            if key in comms:
                comms[key] = str(comms[key])

    response = jsonify(cfg.get(tab_name, {}))
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    return response

@app.route('/save-config', methods=['POST'])
def save_config():
    global config, register_type, last_register, last_resolution, FPS
    global mirror_conn, mirror_sock, ser, alarm_active

    data = request.get_json() or {}

    with config_lock:

        # =========================================================
        # 🔹 LOAD CONFIG
        # =========================================================
        with open(CONFIG_FILE, 'r') as f:
            cfg = yaml.safe_load(f) or copy.deepcopy(DEFAULT_CONFIG)

        old_cfg = copy.deepcopy(cfg)

        # =========================================================
        # 🔹 APPLY INCOMING UPDATES
        # =========================================================
        for tab, updates in data.items():

            cfg.setdefault(tab, {})

            for key, value in updates.items():

                # -------------------------------------------------
                # Inline numeric conversion (NO NUMERIC_KEYS)
                # -------------------------------------------------
                if tab == "Communications":
                    if key in ("BaudRate", "DataBits", "StopBits"):
                        try:
                            value = int(value)
                        except (ValueError, TypeError):
                            pass

                cfg[tab][key] = value

        system = cfg.setdefault("System", {})

        # =========================================================
        # 🖥️ ONSCREEN
        # =========================================================
        onscreen_old = old_cfg.get("Onscreen", {})
        onscreen_new = cfg.get("Onscreen", {})

        apply_onscreen_config(onscreen_new)

        onscreen_keys_restart = [
            "TextSize", "Vertical_Pos", "Horizontal_Pos",
            "Displayline", "Displaywidth",
            "Textcolor", "Backgroundcolor",
            "Textforeground", "Textbackground",
            "Bold", "Language", "Spacingline"
        ]

        if any(onscreen_old.get(k) != onscreen_new.get(k) for k in onscreen_keys_restart):
            system["RestartCapture"] = True

        # =========================================================
        # 🔤 REGISTER CHANGE
        # =========================================================
        old_register = onscreen_old.get("Register", "GENERIC")
        new_register = onscreen_new.get("Register", "GENERIC")

        if old_register != new_register:

            defaults = FILTER_DEFAULTS.get(new_register, {})

            for k, v in defaults.get("Communications", {}).items():
                cfg.setdefault("Communications", {})[k] = v

            for k, v in defaults.get("Onscreen", {}).items():
                cfg.setdefault("Onscreen", {})[k] = v

            register_type = new_register
            last_register = new_register

            restart_input_receiver()

        # =========================================================
        # 🎥 VIDEO CONTROL
        # =========================================================
        video_old = old_cfg.get("Video", {})
        video_new = cfg.get("Video", {})

        video_keys = [
            "brightness", "contrast", "saturation",
            "hue", "sharpness",
            "Vertical_flip", "Horizontal_flip"
        ]

        if any(video_old.get(k) != video_new.get(k) for k in video_keys):
            apply_camera_controls(video_new)
            apply_video_pipeline(video_new)

        # =========================================================
        # 🎞️ RESOLUTION
        # =========================================================
        if video_old.get("Videoresolution") != video_new.get("Videoresolution"):

            resolution = str(video_new.get("Videoresolution", "1080P")).upper()

            defaults = RESOLUTION_DEFAULTS.get(resolution)

            if defaults:

                onscreen = cfg.setdefault("Onscreen", {})

                onscreen.update({
                    "Vertical_Pos": defaults["Vertical_Pos"],
                    "Horizontal_Pos": defaults["Horizontal_Pos"],
                    "Vertical_Max": defaults["Vertical_Max"],
                    "Horizontal_Max": defaults["Horizontal_Max"],
                    "Displayline": defaults["Displayline"],
                    "Displaywidth": defaults["Displaywidth"],
                    "TextSize": defaults["TextSize"],
                    "Bold": defaults["Bold"]
                })

            last_resolution = resolution

            system["RestartCapture"] = True
            system["RestartStream"] = True

        # =========================================================
        # 🎞️ FPS
        # =========================================================
        if video_old.get("Framerate") != video_new.get("Framerate"):
            FPS = video_new.get("Framerate")
            system["RestartCapture"] = True
            system["RestartStream"] = True

        # =========================================================
        # 🌐 NETWORK
        # =========================================================
        comms_old = old_cfg.get("Communications", {})
        comms_new = cfg.get("Communications", {})

        if comms_old.get("Httpport") != comms_new.get("Httpport"):
            system["RestartHTTP"] = True

        if comms_old.get("Streamport") != comms_new.get("Streamport"):
            system["RestartStream"] = True

        # =========================================================
        # 🔁 MIRROR
        # =========================================================
        if (
            comms_old.get("TargetIP") != comms_new.get("TargetIP") or
            comms_old.get("Mirorport") != comms_new.get("Mirorport") or
            comms_old.get("Miror_Output") != comms_new.get("Miror_Output")
        ):
            mirror_conn = None
            mirror_sock = None
            apply_overlay_network_config(comms_new)

        # =========================================================
        # 🔌 SERIAL
        # =========================================================
        if (
            comms_old.get("SerialPort") != comms_new.get("SerialPort") or
            comms_old.get("BaudRate") != comms_new.get("BaudRate") or
            comms_old.get("DataBits") != comms_new.get("DataBits") or
            comms_old.get("StopBits") != comms_new.get("StopBits") or
            comms_old.get("Parity") != comms_new.get("Parity")
        ):
            apply_serial_control(comms_new)           
            restart_input_receiver()

        # =========================================================
        # 🚨 ALARM SYSTEM
        # =========================================================
        video_old = old_cfg.get("Video", {})
        video_new = cfg.get("Video", {})

        alarm_list = cfg.setdefault("Alarm", {}).setdefault("List", [])

        old_index = int(video_old.get("Alarm_number", 1)) - 1
        new_index = int(video_new.get("Alarm_number", 1)) - 1

        while len(alarm_list) <= max(old_index, new_index):
            alarm_list.append({
                "Alarm_output": False,
                "Alarm_state": "NC",
                "Alarm_duration": 100,
                "Trigger_text": ""
            })

        if old_index != new_index:

            alarm_list[old_index] = {
                "Alarm_output": video_new.get("Alarm_output"),
                "Alarm_state": video_new.get("Alarm_state"),
                "Alarm_duration": video_new.get("Alarm_duration"),
                "Trigger_text": video_new.get("Trigger_text")
            }

            selected = alarm_list[new_index]

            cfg["Video"].update({
                "Alarm_output": selected.get("Alarm_output", False),
                "Alarm_state": selected.get("Alarm_state", "NC"),
                "Alarm_duration": selected.get("Alarm_duration", 100),
                "Trigger_text": selected.get("Trigger_text", "")
            })

        else:
            alarm_list[new_index] = {
                "Alarm_output": video_new.get("Alarm_output"),
                "Alarm_state": video_new.get("Alarm_state"),
                "Alarm_duration": video_new.get("Alarm_duration"),
                "Trigger_text": video_new.get("Trigger_text")
            }

        if (
            video_old.get("Alarm_output") != cfg["Video"].get("Alarm_output") or
            video_old.get("Alarm_state") != cfg["Video"].get("Alarm_state") or
            video_old.get("Alarm_duration") != cfg["Video"].get("Alarm_duration")
        ):
            update_alarm_system(
                enabled=cfg["Video"].get("Alarm_output"),
                state=cfg["Video"].get("Alarm_state"),
                duration=cfg["Video"].get("Alarm_duration")
            )

        if video_old.get("Alarm_state") != video_new.get("Alarm_state"):
            if not alarm_active:
                set_alarm_output(False)

        # =========================================================
        # 🔁 FLAGS
        # =========================================================
        if system.get("RestartCapture"):
            system["RestartCapture"] = True

        if system.get("RestartStream"):
            system["RestartStream"] = True

        system["ReloadUI"] = True

        # =========================================================
        # 💾 SAVE CONFIG
        # =========================================================
        with open(CONFIG_FILE, 'w') as f:
            yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)

        config = cfg

    return jsonify({"status": "saved"}), 100

# ================= OTA API =================
@app.route("/api/ota/status", methods=["GET"])
def ota_status():
    with open(CONFIG_FILE, "r") as f:
        cfg = yaml.safe_load(f) or {}
    return jsonify(cfg.get("System", {}))

@app.route("/api/ota/request", methods=["POST"])
def ota_request():
    with config_lock:
        with open(CONFIG_FILE, "r") as f:
            cfg = yaml.safe_load(f) or {}

        cfg.setdefault("System", {})
        cfg["System"]["UpdateRequested"] = True
        cfg["System"]["UpdateState"] = "CHECKING"

        with open(CONFIG_FILE, "w") as f:
            yaml.dump(cfg, f, sort_keys=False)

    return jsonify({"status": "ok"})

@app.route('/templates/<path:filename>')
def serve_template_file(filename):
    return send_from_directory('templates', filename)
# -------------------- Main ------------------------------
if __name__ == "__main__":

    # =====================================================
    # SYSTEM FLAGS
    # =====================================================

    initialize_system_flags()

    # =====================================================
    # LOAD CONFIG
    # =====================================================

    with open(CONFIG_FILE) as f:
        config = yaml.safe_load(f) or {}

    globals()["config"] = config

    # =====================================================
    # INIT RUNTIME
    # =====================================================

    initialize_runtime_config()

    # =====================================================
    # NETWORK  (this will start capture thread)
    # =====================================================
    init_network_from_config()

    # =====================================================
    # INPUT / GPIO
    # =====================================================

    start_input_receiver()

    init_alarm_gpio()

    threading.Thread(
        target=alarm_worker,
        daemon=True
    ).start()

    # =====================================================
    # READ CONFIG
    # =====================================================

    with config_lock:

        comm = config.get("Communications", {})
        video = config.get("Video", {})

        host_ip = comm.get("IP", "0.0.0.0")

        STREAM_PORT = comm.get("Streamport", 554)

        HTTP_PORT = comm.get("Httpport", 80)

        resolution = video.get(
            "Videoresolution",
            "1080P"
        )

        CAP_WIDTH, CAP_HEIGHT = get_resolution(
            resolution
        )

        FPS = parse_fps_safe(
            video.get("Framerate", "25FPS")
        )

    print(
        f"[CONFIG] "
        f"{CAP_WIDTH}x{CAP_HEIGHT}@{FPS}"
    )

    # =====================================================
    # FREE PORTS
    # =====================================================

    free_port(HTTP_PORT)

    free_port(STREAM_PORT)

    # =====================================================
    # SYSTEM WORKER
    # =====================================================

    worker_thread = threading.Thread(
        target=system_worker,
        daemon=True
    )

    worker_thread.start()

    print("[SYSTEM] Worker thread started")

    # =====================================================
    # RTSP SERVER
    # =====================================================

    gst_thread = GstRtspServerThread(
        host_ip,
        STREAM_PORT,
        CAP_WIDTH,
        CAP_HEIGHT,
        FPS
    )

    gst_thread.start()

    print(
        f"[RTSP] "
        f"rtsp://{host_ip}:{STREAM_PORT}/live"
    )

    # =====================================================
    # HTTP SERVER
    # =====================================================

    print(
        f"[HTTP] "
        f"http://{host_ip}:{HTTP_PORT}"
    )

    app.run(
        host="0.0.0.0",
        port=HTTP_PORT,
        threaded=True
    )