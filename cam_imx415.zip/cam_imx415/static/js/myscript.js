// Tab names corresponding to order in HTML
// Global variable for the current tab
/*
const resolutionProfiles = {
  "720P":  { Vertical_Max: 700,  Horizontal_Max: 1250, Displayline: 42, Displaywidth: 60, TextSize: 2, Bold: 1 },
  "1080P": { Vertical_Max: 1000, Horizontal_Max: 1900, Displayline: 52, Displaywidth: 70, TextSize: 3, Bold: 2 },
  "1440P": { Vertical_Max: 1100, Horizontal_Max: 2500, Displayline: 62, Displaywidth: 70, TextSize: 4, Bold: 3 },
  "4K":    { Vertical_Max: 2100, Horizontal_Max: 3800, Displayline: 82, Displaywidth: 70, TextSize: 4, Bold: 4 }
};*/

const tabNames = ["Video", "Onscreen", "Communications", "Password"];
let tabName = "Video"; // default tab

// Ensure tab shows only after DOM is fully loaded//----------------------------------------------------------->First sequence to load default TAP 
/*not save tap while active when hit refresh
window.addEventListener('DOMContentLoaded', () => {
    const defaultIndex = tabNames.indexOf(tabName);

    if (defaultIndex !== -1) {
      showTab(defaultIndex); // ✅ load default tab safely
    }
  });*/


/*
function showTab(index) {
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');

    // Prevent error on invalid index
    if (index < 0 || index >= tabs.length || index >= tabContents.length || index >= tabNames.length) {
      console.warn(`Invalid tab index: ${index}`);
      return;
    }

    // Activate the selected tab
    tabs.forEach((tab, i) => {
      tab.classList.toggle('active', i === index);
    });

    // Show the corresponding tab content
    tabContents.forEach((content, i) => {
      content.classList.toggle('active', i === index);
    });

    // Set current tab name and load config
    tabName = tabNames[index];
    localStorage.setItem("activeTab", tabName); // <-- persist active tab

    /*
    if (tabName === "Onscreen" && Res_flag) {
      // Wait for the resolution update to complete before loading config
      applyResolutionToOnscreen(res_now).then(() => {
        Res_flag = false;
        loadConfig(); // now safe
      });
    } else {
      loadConfig();
    }*/
   /*
    loadConfig();
    
/*}*/

function showTab(index) {
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');

    if (index < 0 || index >= tabs.length || index >= tabContents.length || index >= tabNames.length) {
        console.warn(`Invalid tab index: ${index}`);
        return;
    }

    // Activate the clicked tab
    tabs.forEach((tab, i) => tab.classList.toggle('active', i === index));
    tabContents.forEach((content, i) => content.classList.toggle('active', i === index));

    // Set current tab name
    tabName = tabNames[index];
    localStorage.setItem("activeTab", tabName);

    // Load fresh data from the server
    loadConfig(tabName); // <--- use cache-busting inside loadConfig
}

//save tap while active page
/*
window.addEventListener('DOMContentLoaded', () => {
  // Try to get the last active tab from localStorage
  const savedTab = localStorage.getItem("activeTab");
  const defaultIndex = savedTab ? tabNames.indexOf(savedTab) : tabNames.indexOf(tabName);

  if (defaultIndex !== -1) {
    showTab(defaultIndex); // load saved tab safely
  }
});  */
function setValue(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  el.value = value;
}

function setChecked(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  el.checked = value;
}

function setText(id, text) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = text;
}

function setAttr(id, attr, value) {
  const el = document.getElementById(id);
  if (el) el.setAttribute(attr, value);
}

function updateColorButton(buttonId, alpha) {
    const btn = document.getElementById(buttonId);
    btn.style.opacity = alpha / 255;
}
// Restore the last active tab after page reload (if page actually reloads)
window.addEventListener('DOMContentLoaded', () => {
    const savedTab = localStorage.getItem("activeTab") || tabNames[0];
    const index = tabNames.indexOf(savedTab);
    if (index !== -1) showTab(index);
});

// Load config for the current tab
function loadConfig(tabName) {
    fetch(`/load-config/${tabName}?_=${Date.now()}`, {cache: "no-store"})
      .then(res => res.json())
      .then(data => {
         console.log("Loaded fresh data:", data); 

            if (tabName === "Video") {

              // Resolution & FPS
              setValue("resolution-select", data.Videoresolution ?? "720P");
              setValue("framerate-select", data.Framerate ?? "25FPS");

              // Brightness
              const brightness = data.brightness ?? 50;
              setValue("brightness-slider", brightness);
              setText("brightness-value", brightness + "%");

              // Contrast
              const contrast = data.contrast ?? 50;
              setValue("contrast-slider", contrast);
              setText("contrast-value", contrast + "%");

              // Saturation
              const saturation = data.saturation ?? 50;
              setValue("saturation-slider", saturation);
              setText("saturation-value", saturation + "%");
              
              // Hue
              const hue = data.hue ?? 50;
              setValue("hue-slider", hue);
              setText("hue-value", hue + "%");

              // Sharpness
              const sharpness = data.sharpness ?? 50;
              setValue("sharpness-slider", sharpness);
              setText("sharpness-value", sharpness + "%");

              // AGC + Gain
              //const agc = data.AGC ?? true;
              //const analogueGain = data.analogue_gain ?? 16;

              // AE + Exposure
              //const ae = data.AE ?? false;
              //const exposure = data.exposure ?? 1000;


              // ---------- SET UI VALUES (ALWAYS FIRST) ----------

              // AGC     
              //setText("agc-state", agc ? "ON" : "OFF");
              //setChecked("agc-toggle", agc);

              // Gain
              //setValue("analogue-gain-slider", analogueGain);
              //setText("analogue-gain-value", analogueGain);

              // AE              
              //setText("ae-state", ae ? "ON" : "OFF");
              //setChecked("ae-toggle", ae);

              // Exposure
              //setValue("exposure-slider", exposure);
              //setText("exposure-value", exposure);

              //Alarm Output     
                // ✅ NEW → Alarm Number
              const alarmNumber = data.Alarm_number ?? 1;
              setValue("alarm-number", alarmNumber);
   
              
              const Alarmoutput = data.Alarm_output ?? false;
              setChecked("alarm-toggle", Alarmoutput);
              setText("alarm-state", Alarmoutput ? "ON" : "OFF");
              
              //Alarm State
              setValue("alarm-state-select", data.Alarm_state || "");

            // Alarm Duration
            const alarmDuration = Number(data.Alarm_duration ?? 20);

            setValue("alarm-duration-input", alarmDuration);
            setText("alarm-duration-value", String(alarmDuration));

            setValue("trigger-text", data.Trigger_text ?? "");          



              // ---------- GET ELEMENTS (for disable control) ----------

              const gainSlider = document.getElementById("analogue-gain-slider");
              const exposureSlider = document.getElementById("exposure-slider");

              const gainContainer = gainSlider.parentElement.parentElement;
              const exposureContainer = exposureSlider.parentElement.parentElement;


              // ---------- APPLY AGC RULE ----------

              gainSlider.disabled = agc;

              if (gainContainer) {
                gainContainer.classList.toggle("disabled", agc);
              }


              // ---------- APPLY AE RULE ----------

              exposureSlider.disabled = ae;

              if (exposureContainer) {
                exposureContainer.classList.toggle("disabled", ae);
              }


              // Horizontal Flip
              const hFlip = data.Horizontal_flip ?? false;
              setChecked("hflip-toggle", hFlip);
              setText("hflip-state", hFlip ? "ON" : "OFF");

              // Vertical Flip
              const vFlip = data.Vertical_flip ?? false;
              setChecked("vflip-toggle", vFlip);
              setText("vflip-state", vFlip ? "ON" : "OFF");
            }
            if (tabName === "Onscreen") {

              setValue("register-driver", data.Register || "");

              setValue("language-driver", data.Language || "");

              setValue("camera-titler", data.Titler || "");

              const titlerDisplay = data.Titlerdisplay ?? false;
              setChecked("titlerdisplay-toggle", titlerDisplay);
              setText("titlerdisplay-state", titlerDisplay ? "ON" : "OFF");

              setValue("time-formate", data.Timeformate || "");
              setValue("date-formate", data.Dateformate || "");

              const tdDisplay = data.TDdisplay ?? false;
              setChecked("TDdisplay-toggle", tdDisplay);
              setText("TDdisplay-state", tdDisplay ? "ON" : "OFF");

              // Vertical
              setAttr("vertical-slider", "max", data.Vertical_Max ?? 700);
              setValue("vertical-slider", data.Vertical_Pos ?? 20);
              setText("vertical-value", data.Vertical_Pos ?? 20);

              // Horizontal
              setAttr("horizontal-slider", "max", data.Horizontal_Max ?? 1250);
              setValue("horizontal-slider", data.Horizontal_Pos ?? 15);
              setText("horizontal-value", data.Horizontal_Pos ?? 15);

              // Display line    
              setValue("Displayline-slider", data.Displayline ?? 40);
              setText("Displayline-value", data.Displayline ?? 40);

              // Line spacing
              setValue("Spacingline-slider", data.Spacingline ?? 4);
              setText("Spacingline-value", data.Spacingline ?? 4);

              //Display Width    
              setValue("Displaywidth-select",data.Displaywidth || "");           
                  
              // Screen blanking
              setValue("Screenblanking-slider", data.Screenblanking ?? 20);
              setText("Screenblanking-value", (data.Screenblanking ?? 20) + "s");

              const scrollDelay = data.Scrolldelay ?? false;
              setChecked("Scrolldelay-toggle", scrollDelay);
              setText("Scrolldelay-state", scrollDelay ? "ON" : "OFF");

              const textDisplay = data.Textdisplay ?? true;
              setChecked("Textdisplay-toggle", textDisplay);
              setText("Textdisplay-state", textDisplay ? "ON" : "OFF");

              setValue("Textsize-select", data.TextSize ?? "0");

            // Foreground / Background
              setValue("Textforeground-slider", data.Textforeground ?? 255);
              setText("Textforeground-value", data.Textforeground ?? 255);

              setValue("Textbackground-slider", data.Textbackground ?? 60);
              setText("Textbackground-value", data.Textbackground ?? 60);
          // Update color button backgrounds
              const fgBtn = document.getElementById("fgBtn");
              const bgBtn = document.getElementById("bgBtn");

              // Foreground color
              const fgValue = data.Textforeground ?? 255;
              fgBtn.style.backgroundColor = data.Textcolor || "white";
              fgBtn.style.opacity = fgValue / 255;

              // Background color
              const bgValue = data.Textbackground ?? 60;
              bgBtn.style.backgroundColor = data.Backgroundcolor || "black";
              bgBtn.style.opacity = bgValue / 255;

            }
            if (tabName === "Communications") {

              setValue("streammode-select", data.Streammode ?? "");

              loadIPGroup("ip-config", data.IP);
              loadIPGroup("gateway-config", data.Gateway);
              loadIPGroup("subnet-config", data.Subnet);
              loadIPGroup("target-ip", data.TargetIP);

              setValue("streamport", data.Streamport ?? "");
              setValue("httpport", data.Httpport ?? "");
              setValue("overlayport", data.Overlayport ?? "");
              setValue("mirrorport", data.Mirorport ?? "");

              // Mirror Output
              const mirrorOut = data.Miror_Output ?? false;
              setChecked("mirroroutput-toggle", mirrorOut);
              setText("mirroroutput-state", mirrorOut ? "ON" : "OFF");

              // Text Protocol
              setValue("textprotocol-select", data.Textprotocol ?? "TCP");

              // SERIAL SECTION
              setValue("inputselection-select", data.InputSelection ?? "Serial");
              setValue("baudrate-select", data.BaudRate ?? "9600");
              setValue("databits-select", data.DataBits ?? "8");
              setValue("stopbits-select", data.StopBits ?? "1");
              setValue("parity-select", data.Parity ?? "NONE");

              const hs = data.HandShaking ?? false;
              setChecked("handshaking-toggle", hs);
              setText("handshaking-state", hs ? "ON" : "OFF");
            }      
            if (tabName === "Password") {
            }         
 
      })
      .catch(err => console.error("Failed to load config:", err));  
     
    }
// Apply default asper each resolution
/* move to backend
function applyResolutionToOnscreen(resName) {
  const resConfig = resolutionProfiles[resName];
  if (!resConfig) return Promise.reject("Unknown resolution");

  const payload = { "Onscreen": resConfig };

  return fetch("/save-config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
  .then(res => res.json())
  .then(data => {
    console.log(`Applied ${resName} to Onscreen:`, data);
    return data; // resolve the promise
  })
  .catch(err => console.error("Failed to save config:", err));
}*/

// Function to apply register and handle Miror_Output
/* mov to backend
function applyRegisterDriver(registerName) {
  if (!registerName) return Promise.reject("No register selected");

  // Explicitly set Miror_Output
  let mirrorStatus = true; // default
  if (registerName === "GENERIC-NTXY" || registerName === "GENERIC-SLXY") {
    mirrorStatus = false;
  }
  const payload = {
    "Communications": { "Miror_Output": mirrorStatus }
  };

  return fetch("/save-config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
  .then(res => res.json())
  .then(data => {
    console.log(`Applied Register: ${registerName}, Miror_Output: ${mirrorStatus}`, data);
    return data;
  })
  .catch(err => console.error("Failed to save Register config:", err));
}*/

/* Original code
 // Update config to server
  function updateConfig(key, value) {
    const payload = {};
    payload[tabName] = { [key]: value };

    fetch("/save-config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    })
      .then(res => {
        if (!res.ok) {
          console.error("Failed to save config:", res.status, res.statusText);
        } else {
          console.log("Config saved:", payload);
        }
      })
      .catch(err => console.error("Error:", err));
  }
*/

/*New driver support to save crossing tap*/
function updateConfig(tabName, key, value) {
  const payload = {};
  payload[tabName] = { [key]: value };

  fetch("/save-config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  })
    .then(res => {
      if (!res.ok) {
        console.error("Failed to save config:", res.status, res.statusText);
      } else {
        console.log("Config saved:", payload);
        
      }
    })
    .catch(err => console.error("Error:", err));
}

//Saving VIDEO 
(function ()   { 
        //Video Resolution ------------------------------------------------------------------------->
        const resolutionSelect = document.getElementById("resolution-select");
        resolutionSelect.addEventListener("change", function () {
              updateConfig("Video","Videoresolution", this.value);   
        });
    
        //Frame Rate ------------------------------------------------------------------------------>
        const framerateSelect = document.getElementById("framerate-select");
        framerateSelect.addEventListener("change", function () {
          updateConfig("Video","Framerate", this.value);
        });

        // Brightness------------------------------------------------------------------------------->
        const brightnessSlider = document.getElementById("brightness-slider");
        // Show live value
        brightnessSlider.addEventListener("input", function () {
          const val = Number(brightnessSlider.value);
          document.getElementById("brightness-value").textContent = val + "%";
        });
        // Save only final value
         brightnessSlider.addEventListener("change", function () {
          const val = Number(brightnessSlider.value);
          console.log("Saving brightness:", val); // Final value after release
          updateConfig("Video","brightness", val);
        });

        // Contrast-------------------------------------------------------------------------------->
        const contrastSlider = document.getElementById("contrast-slider");
        // Live update
        contrastSlider.addEventListener("input", function () {
          const val = Number(contrastSlider.value);
          document.getElementById("contrast-value").textContent = val + "%";
        });
        // Save only final value
        contrastSlider.addEventListener("change", function () {
          const val = Number(contrastSlider.value);
          updateConfig("Video","contrast", val);
        });

        // Saturation------------------------------------------------------------------------------->
        const saturationSlider = document.getElementById("saturation-slider");
        // Live update
        saturationSlider.addEventListener("input", function () {
          const val = Number(saturationSlider.value);
          document.getElementById("saturation-value").textContent = val + "%";
        });
        // Save only final value
        saturationSlider.addEventListener("change", function () {
          const val = Number(saturationSlider.value);
          updateConfig("Video","saturation", val);
        });   

        // Hue-------------------------------------------------------------------------------------->
        const hueSlider = document.getElementById("hue-slider");
        // Live update
        hueSlider.addEventListener("input", function () {
          const val = Number(hueSlider.value);
          document.getElementById("hue-value").textContent = val + "%";
        });

        // Save only final value
        hueSlider.addEventListener("change", function () {
          const val = Number(hueSlider.value);
          updateConfig("Video", "hue", val);
        });

        // Sharpness--------------------------------------------------------------------------------->
        const sharpnessSlider = document.getElementById("sharpness-slider");
        // Live update
        sharpnessSlider.addEventListener("input", function () {
          const val = Number(sharpnessSlider.value);
          document.getElementById("sharpness-value").textContent = val + "%";
        });

        // Save only final value
        sharpnessSlider.addEventListener("change", function () {
          const val = Number(sharpnessSlider.value);
          updateConfig("Video", "sharpness", val);
        });        

      // AGC Toggle---------------------------------------------------------------------------------->

        //const agcToggle = document.getElementById("agc-toggle");
        //const gainSlider = document.getElementById("analogue-gain-slider");
        //const agcState   = document.getElementById("agc-state");

        // Toggle AGC
        /*
        agcToggle.addEventListener("change", () => {
          const agc = agcToggle.checked;

          agcState.textContent = agc ? "ON" : "OFF";

          gainSlider.disabled = agc;

          gainSlider.closest(".slider-container")
                    .classList.toggle("disabled", agc);
        */
        // If turning OFF AGC, refresh UI value
        /*
          if (!agc) {
            gainSlider.dispatchEvent(new Event("input"));
          }
         updateConfig("Video", "AGC", agc);
        });*/

        // Gain slider live update
        /*
        gainSlider.addEventListener("input", () => {
          if (gainSlider.disabled) return;

          const val = Number(gainSlider.value);
          document.getElementById("analogue-gain-value").textContent = val;
        });*/

        // Save on release ONLY once
        /*
        gainSlider.addEventListener("change", () => {
          if (gainSlider.disabled) return;
          const val = Number(gainSlider.value);
          updateConfig("Video", "analogue_gain", val);
        });*/

        
        //const aeToggle = document.getElementById("ae-toggle");
        //const exposureSlider = document.getElementById("exposure-slider");
        //const aeState = document.getElementById("ae-state");

        // Toggle AE
        /*
        aeToggle.addEventListener("change", () => {
          const ae = aeToggle.checked;

          aeState.textContent = ae ? "ON" : "OFF";

          exposureSlider.disabled = ae;

          exposureSlider.closest(".slider-container")
                        .classList.toggle("disabled", ae);
        */
       // If turning OFF AGC, refresh UI value
       /*
          if (!ae) {
            exposureSlider.dispatchEvent(new Event("input"));
          }

          updateConfig("Video", "AE", ae);
        });*/

        // Exposure live update
        /*
        exposureSlider.addEventListener("input", () => {
          if (exposureSlider.disabled) return;

          const val = Number(exposureSlider.value);
          document.getElementById("exposure-value").textContent = val;
        });*/

        // Save on release ONLY once
        /*
        exposureSlider.addEventListener("change", () => {
          if (exposureSlider.disabled) return;

          const val = Number(exposureSlider.value);
          updateConfig("Video", "exposure", val);
        });*/

      // Horizontal Flip Toggle ------------------------------------------------------------------------
      const hflipToggle = document.getElementById("hflip-toggle");
      hflipToggle.addEventListener("change", () => {
        const status = hflipToggle.checked;
        document.getElementById("hflip-state").textContent = status ? "ON" : "OFF";
        updateConfig("Video","Horizontal_flip", status);
      });

      // Vertical Flip Toggle --------------------------------------------------------------------------
      const vflipToggle = document.getElementById("vflip-toggle");
      vflipToggle.addEventListener("change", () => {
        const status = vflipToggle.checked;
        document.getElementById("vflip-state").textContent = status ? "ON" : "OFF";
        updateConfig("Video","Vertical_flip", status);
      });

      // Alarm Output--------------------------------------------------------------------------------->
      const alarmNumberSelect = document.getElementById("alarm-number");
      alarmNumberSelect.addEventListener("change", function () {
        const val = Number(this.value);
        updateConfig("Video", "Alarm_number", val);
      });

      const alarmToggle = document.getElementById("alarm-toggle");
      alarmToggle.addEventListener("change", () => {
        const status = alarmToggle.checked;
        document.getElementById("alarm-state").textContent = status ? "ON" : "OFF";
        updateConfig("Video", "Alarm_output", status);
      });

      const alarmStateSelect = document.getElementById("alarm-state-select");
      alarmStateSelect.addEventListener("change", () => {
      const value = alarmStateSelect.value;
      updateConfig("Video", "Alarm_state", value);      
      });

      const alarmDurationInput = document.getElementById("alarm-duration-input");

      alarmDurationInput.addEventListener("change", () => {
        let value = Number(alarmDurationInput.value);

        // safety clamp
        if (Number.isNaN(value)) value = 1;
        if (value < 1) value = 1;
        if (value > 1000) value = 1000;

        // force numeric value in input
        alarmDurationInput.value = value;

        // ❗ IMPORTANT: ensure it's a real number type
        updateConfig("Video", "Alarm_duration", Number(value));
      });
      
      // Trigger Text --------------------------------------------------------------------------->
      document.getElementById("trigger-text").addEventListener("input", (e) => {
        updateConfig("Video", "Trigger_text", e.target.value);
      });


})();


//Saving ONSCREEN DISPLAY
(function ()   { 

      // Register Driver ------------------------------------------------------------------------>
      const registerSelect = document.getElementById("register-driver");
      registerSelect.addEventListener("change", function () {
        updateConfig("Onscreen","Register", this.value);        
      });

      // Lanaguage Driver ------------------------------------------------------------------------>
      const languageSelect = document.getElementById("language-driver");
      languageSelect.addEventListener("change", function () {
        updateConfig("Onscreen","Language", this.value);        
      });


      // Camera Tilter--------------------------------------------------------------------------->
      document.getElementById("camera-titler").addEventListener("input", (e) => {
        updateConfig("Onscreen","Titler", e.target.value);
      });
 
      // Tiler ---------------------------------------------------------------------------------->
      const titlerDisplayToggle = document.getElementById("titlerdisplay-toggle");
      titlerDisplayToggle.addEventListener("change", () => {
        const status = titlerDisplayToggle.checked;
        document.getElementById("titlerdisplay-state").textContent = status ? "ON" : "OFF";
        updateConfig("Onscreen","Titlerdisplay", status); // Save state using your updateConfig function
      });     
     // time Sync--------------------------------------------------------------------------------> 
     /*     
      const timeSyncToggle = document.getElementById("TDsync-toggle");
      timeSyncToggle.addEventListener("change", () => {
        const status = timeSyncToggle.checked;
        document.getElementById("TDsync-state").textContent = status ? "ON" : "OFF";
        updateConfig("Onscreen","TDsync", status); // Save to config
      });  */  

      // Time Date formate----------------------------------------------------------------------------->  
      document.getElementById("time-formate").addEventListener("input", (e) => {
        updateConfig("Onscreen","Timeformate", e.target.value);
      });

      // Date formate----------------------------------------------------------------------------->  
      document.getElementById("date-formate").addEventListener("input", (e) => {
        updateConfig("Onscreen","Dateformate", e.target.value);
      });
      
      // Vertical Slider----------------------------------------------------------------------------->  
      const verticalSlider = document.getElementById("vertical-slider");
      verticalSlider.addEventListener("input", function () {
        document.getElementById("vertical-value").textContent = this.value;
      });
       // Save final value
      verticalSlider.addEventListener("change", function () {
        updateConfig("Onscreen","Vertical_Pos", Number(this.value));
      });        

      // Horizontal Slider----------------------------------------------------------------------------->  
      
      const horizontalSlider = document.getElementById("horizontal-slider");
      horizontalSlider.addEventListener("input", function () {
        document.getElementById("horizontal-value").textContent = this.value;
      });
      // Save final value
      horizontalSlider.addEventListener("change", function () {
        updateConfig("Onscreen","Horizontal_Pos", Number(this.value));
      });   

      // Display Line----------------------------------------------------------------------------->  
      const displayLineSlider = document.getElementById("Displayline-slider");
      displayLineSlider.addEventListener("input", function () {
        document.getElementById("Displayline-value").textContent = this.value;
      });  
      // Displayline - save value
      displayLineSlider.addEventListener("change", function () {
        updateConfig("Onscreen","Displayline", Number(this.value));
      });
      
      // Line Spacing----------------------------------------------------------------------------->  
      const linespacingSlider = document.getElementById("Spacingline-slider");
      linespacingSlider.addEventListener("input", function () {
        document.getElementById("Spacingline-value").textContent = this.value;
      });  
      // Line Spacing - save value
      linespacingSlider.addEventListener("change", function () {
        updateConfig("Onscreen","Spacingline", Number(this.value));
      });


      // Save Display Width on change  
      const displayWidthSelect = document.getElementById("Displaywidth-select");
      displayWidthSelect.addEventListener("change", function () {
        updateConfig("Onscreen", "Displaywidth", parseInt(this.value, 10));
      });

      // TD Eanble/Disable display------------------------------------------------------------------->      
      const tdDisplayToggle = document.getElementById("TDdisplay-toggle");
      tdDisplayToggle.addEventListener("change", () => {
        const status = tdDisplayToggle.checked;
        document.getElementById("TDdisplay-state").textContent = status ? "ON" : "OFF";
        updateConfig("Onscreen","TDdisplay", status); // Save to backend
      });     

      // ---- Text Foreground ----
      const textForegroundSlider = document.getElementById("Textforeground-slider");
      textForegroundSlider.addEventListener("input", function () {
          const val = Number(textForegroundSlider.value);
          document.getElementById("Textforeground-value").textContent = val;
          updateColorButton("fgBtn", val); // live update opacity
      });
      textForegroundSlider.addEventListener("change", function () {
          const val = Number(textForegroundSlider.value);
          updateConfig("Onscreen","Textforeground", val);
          updateColorButton("fgBtn", val); // update after save
      });

      // ---- Text Background ----
      const textBackgroundSlider = document.getElementById("Textbackground-slider");
      textBackgroundSlider.addEventListener("input", function () {
          const val = Number(textBackgroundSlider.value);
          document.getElementById("Textbackground-value").textContent = val;
          updateColorButton("bgBtn", val); // live update
      });
      textBackgroundSlider.addEventListener("change", function () {
          const val = Number(textBackgroundSlider.value);
          updateConfig("Onscreen","Textbackground", val);
          updateColorButton("bgBtn",  val); // update after save
      });    

      // Screen Blanking----------------------------------------------------------------------->        
      const screenBlankingSlider = document.getElementById("Screenblanking-slider");

      // Live update
      screenBlankingSlider.addEventListener("input", function () {
        const val = Number(screenBlankingSlider.value);
        document.getElementById("Screenblanking-value").textContent = val + "S";
      });
      
      // Save only the final value
      screenBlankingSlider.addEventListener("change", function () {
        const val = Number(screenBlankingSlider.value);
        updateConfig("Onscreen","Screenblanking", val); // Save the value with updateConfig
      });      

      // Left Justify---------------------------------------------------------------------------->  
      /*          
      const leftJustifyToggle = document.getElementById("Leftjustify-toggle");
      leftJustifyToggle.addEventListener("change", () => {
        const status = leftJustifyToggle.checked;
        document.getElementById("Leftjustify-state").textContent = status ? "ON" : "OFF";
        updateConfig("Onscreen","Leftjustify", status);
      }); */

      // Scroll Delay--------------------------------------------------------------------------->  
      const scrollDelayToggle = document.getElementById("Scrolldelay-toggle");
      scrollDelayToggle.addEventListener("change", () => {
        const status = scrollDelayToggle.checked;
        document.getElementById("Scrolldelay-state").textContent = status ? "ON" : "OFF";
        updateConfig("Onscreen","Scrolldelay", status);
      });    
      
      // Text Size on change------------------------------------------------------------------->

      const textSizeSelect = document.getElementById("Textsize-select");
      textSizeSelect.addEventListener("change", function () {
        updateConfig("Onscreen","TextSize", Number(this.value));  // convert string → number
      });

      //Overlay Language on change --------------------------------------------------------------->
      /*
      const languageSelect = document.getElementById("Language-select");
      languageSelect.addEventListener("change", function () {
        updateConfig("Onscreen","Language", this.value);
      }); */     

      // Text Display--------------------------------------------------------------------------->  
      const textDisplayToggle = document.getElementById("Textdisplay-toggle");
      textDisplayToggle.addEventListener("change", () => {
        const status = textDisplayToggle.checked;
        document.getElementById("Textdisplay-state").textContent = status ? "ON" : "OFF";
        updateConfig("Onscreen","Textdisplay", status);
      });

})(); 
   
//Saving COMMUNICATION
(function ()   { 


        // Save Stream Mode -------------------------------------------------------------------------->
        /* move to network applying
        const streamModeSelect = document.getElementById("streammode-select");
        streamModeSelect.addEventListener("change", function () {
        updateConfig("Communications","Streammode", this.value);

        });
      
        // Attach IP listeners for auto-saving #suppressed Let Apply network save it
        //attachIPListener("ip-config", "IP");
        //attachIPListener("gateway-config", "Gateway");
        //attachIPListener("subnet-config", "Subnet");  

        // ----------- Save Port Changes to Config ------------
        document.getElementById("streamport").addEventListener("input", function () {
          updateConfig("Communications","Streamport", this.value.trim());
        });

        document.getElementById("httpport").addEventListener("input", function () {
          updateConfig("Communications","Httpport", this.value.trim());
        });
        */

        // Input Overlay Selection------------------------------------------------>      
        document.getElementById("inputmode-select").addEventListener("change", function () {
            updateConfig("Communications","InputSelection", this.value);
        });

        //Overlay port  
        document.getElementById("overlayport").addEventListener("input", function () {
          updateConfig("Communications","Overlayport", this.value.trim());
        });

        attachIPListener("Communications","target-ip", "TargetIP");


        // Mirror Toggle ---------------------------------
        const mirrorOutputToggle = document.getElementById("mirroroutput-toggle");
        mirrorOutputToggle.addEventListener("change", () => {
          const status = mirrorOutputToggle.checked;
          document.getElementById("mirroroutput-state").textContent = status ? "ON" : "OFF";
          updateConfig("Communications","Miror_Output", status); // Save to backend
        });

        //mirror port  
        document.getElementById("mirrorport").addEventListener("input", function () {
          updateConfig("Communications","Mirorport", this.value.trim());
        });



        // ------------ Save Text Protocol ----------------
        document.getElementById("textprotocol-select").addEventListener("change", function () {
          updateConfig("Communications","Textprotocol", this.value);
        });
        /* later
        // ------------ Save Server ACK -------------------
        serverAckToggle.addEventListener("change", function () {
          const state = this.checked;
          serverAckState.textContent = state ? "ON" : "OFF";
          updateConfig("Communications","Serverack", state);
        });

        // ------------ Save Handshake ---------------------
        handshakeToggle.addEventListener("change", function () {
          const state = this.checked;
          handshakeState.textContent = state ? "ON" : "OFF";
          updateConfig("Communications","Hankshake", state); // Keeping original key spelling
        });*/
       

        // ******************************************************************
        // 🔵 SERIAL COMMUNICATION SETTINGS — Added Below
        // ******************************************************************
        document.getElementById("baudrate-select").addEventListener("change", function () {
          updateConfig("Communications","BaudRate", this.value);
        });

        document.getElementById("databits-select").addEventListener("change", function () {
          updateConfig("Communications","DataBits", this.value);
        });

        document.getElementById("stopbits-select").addEventListener("change", function () {
          updateConfig("Communications","StopBits", this.value);
        });       

        document.getElementById("parity-select").addEventListener("change", function () {
          updateConfig("Communications","Parity", this.value);
        });          
        document.getElementById("handshake-select").addEventListener("change", function () {
          updateConfig("Communications","HandShaking", this.value);
        });  

})();      

//when changing alarm number need to load this tap after saved. data changing in array
document.getElementById("alarm-number").addEventListener("change", async function () {
    const alarmNumber = parseInt(this.value);

    await fetch('/save-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            Video: { Alarm_number: alarmNumber }
        })
    });

    // 🔥 THIS is the correct reload
    loadConfig("Video");
});


// ------------------- Load IP-style Data -------------------
function loadIPGroup(idPrefix, ipString) {
    const inputs = document.querySelectorAll(`#${idPrefix} .ip-octet`);
    const parts = (ipString || "").split(".");
    inputs.forEach((input, index) => {
      input.value = parts[index] || "";
    });
}

// ------------------- Save IP-style Data -------------------
function attachIPListener(containerId, configKey) {
    const inputs = document.querySelectorAll(`#${containerId} .ip-octet`);
    inputs.forEach(input => {
      input.addEventListener("input", () => {
        const ipValue = Array.from(inputs)
          .map(el => el.value.trim())
          .join(".");
        updateConfig(configKey, ipValue);
      });
    });
}

async function myNewcode() {
    const username = document.getElementById("username-titler").value.trim();
    const password = document.getElementById("password-titler").value;
    const confirmPassword = document.getElementById("confirm-new-password-titler").value;
    const btn = document.getElementById("applyBtn");

    // --- Validation ---
    if (username.length < 6 || password.length < 6) {
      showMessage("Username and Password must be at least 6 characters.");
      return;
    }
    if (password !== confirmPassword) {
      showMessage("Passwords do not match.");
      return;
    }

    const payload = {
      Password: {
        Username: username,
        Password: password
      }
    };

    try {
      const resp = await fetch("/save-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);

      showMessage("Settings saved successfully!");

      // clear fields
      document.getElementById("username-titler").value = "";
      document.getElementById("password-titler").value = "";
      document.getElementById("confirm-new-password-titler").value = "";

      // disable button again
      btn.disabled = true;
      btn.style.backgroundColor = "grey";
    } catch (error) {
      console.error(error);
      showMessage("Failed to save settings.");
    }
}

function showMessage(text, color = "#4CAF50") {
      const messageDiv = document.getElementById("saveMessage");
      messageDiv.textContent = text;
      messageDiv.style.backgroundColor = color;
      messageDiv.style.display = "block";
      setTimeout(() => {
          messageDiv.style.display = "none";
      }, 3000);
}  

// Helper delay function (returns a Promise that resolves after ms milliseconds)
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

const factoryCheckbox = document.getElementById("factory-reset-checkbox");
const factoryBtn = document.getElementById("factory-reset-btn");

// Enable/disable button and change color when checkbox toggled
factoryCheckbox.addEventListener("change", () => {
  if (factoryCheckbox.checked) {
    factoryBtn.disabled = false;
    factoryBtn.style.backgroundColor = "#4CAF50"; // Green
    factoryBtn.style.color = "#fff";
  } else {
    factoryBtn.disabled = true;
    factoryBtn.style.backgroundColor = ""; // Default
    factoryBtn.style.color = "";
  }
});

// Trigger reset on button click
factoryBtn.addEventListener("click", applyFactoryReset);

async function applyFactoryReset() {
  if (!factoryCheckbox.checked) {
    showMessage("No reset selected.", "#f44336"); // Red
    return;
  }

  showMessage("Reset initiated... waiting for system", "#FFA000"); // Amber
  await updateConfig("FactoryReset", true);  // Assuming updateConfig returns a Promise

  await delay(200);  // wait 200 ms

  // Fetch updated config to verify reset
  fetch('/load-config/Password')
    .then(response => response.json())
    .then(data => {
      if (data.FactoryReset === false) {
        showMessage("System reset complete.", "#4CAF50"); 
        loadConfig();  // reload config after reset
      } else {
        showMessage("System reset failed.", "#f44336"); 
      }
    })
    .catch(() => {
      showMessage("Error reading reset status.", "#f44336");
    });
}   

//Applying Networkgroup

function getIPValue(containerId) {
  const inputs = document.querySelectorAll(`#${containerId} .ip-octet`);
  return Array.from(inputs).map(input => input.value.trim()).join(".");
}

function isValidIP(ip) {
  const parts = ip.split(".");
  if (parts.length !== 4) return false;

  return parts.every(p => {
    const num = Number(p);
    return p !== "" && !isNaN(num) && num >= 0 && num <= 255;
  });
}
const allInputs = document.querySelectorAll(".ip-octet");

allInputs.forEach(input => {
  input.addEventListener("input", checkAllValid);
});

//Ensure Valid IP to Enable button
function checkAllValid() {
  const ip = getIPValue("ip-config");
  const gateway = getIPValue("gateway-config");
  const subnet = getIPValue("subnet-config");

  const valid = isValidIP(ip) && isValidIP(gateway) && isValidIP(subnet);

  document.getElementById("apply-network-btn").disabled = !valid;
}

//count down 5 s and redirect
function startCountdown(ip, port, seconds) {
  let remaining = seconds;

  updateMessage(`Reconnecting in ${remaining}s...\n${ip}:${port}`);

  const interval = setInterval(() => {
    remaining--;

    if (remaining >= 0) {
      updateMessage(`Reconnecting in ${remaining}s...\n${ip}:${port}`);
    }

    if (remaining < 0) {
      clearInterval(interval);
      window.location.href = `http://${ip}:${port}`;
    }
  }, 1000);
}

//Message Center Box 
const messageBox = document.getElementById("message-center-box");

function showMessage(text) {
  const box = document.getElementById("message-center-box");
  const textEl = box.querySelector(".message-text");

  textEl.innerHTML = text;   // ✅ update text
  box.classList.remove("hidden");
  box.classList.add("show");
}

function hideMessage() {
  messageBox.classList.remove("show");
  messageBox.classList.add("hide");

  // wait for animation to finish
  setTimeout(() => {
    messageBox.classList.add("hidden");
    messageBox.classList.remove("hide");
  }, 250);
}

function updateMessage(text) {
  const textEl = document.querySelector("#message-center-box .message-text");
  textEl.innerHTML = text;
}
//Save Applying Button Click
document.getElementById("apply-network-btn").addEventListener("click", async function () {

  const str = (document.getElementById("streammode-select")?.value || "")
              .trim()
              .toUpperCase();
              
  const ip = getIPValue("ip-config");
  const gateway = getIPValue("gateway-config");
  const subnet = getIPValue("subnet-config");

  // ✅ FIXED: correct way to read ports
  const strport = parseInt(document.getElementById("streamport")?.value, 10);
  const httpport = parseInt(document.getElementById("httpport")?.value, 10);

  if (!isValidIP(ip) || !isValidIP(gateway) || !isValidIP(subnet)) {
    alert("Invalid IP / Gateway / Subnet");
    return;
  }

  if (
    isNaN(strport) || strport <= 0 || strport > 65535 ||
    isNaN(httpport) || httpport <= 0 || httpport > 65535
  ) {
    alert("Invalid port number");
    return;
  }

  // ✅ Use numeric httpport
  showMessage(`Applying network... to ${ip}:${httpport}`);

  try {
    await fetch("/save-config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        Communications: {
          Streammode: str,
          IP: ip,
          Gateway: gateway,
          Subnet: subnet,
          Streamport: strport,
          Httpport: httpport,
          ApplyNetwork: true
        }
      })
    });

    setTimeout(() => {
      startCountdown(ip, httpport, 15);
    }, 2000);

  } catch (err) {
    updateMessage("Failed to apply network");
    setTimeout(hideMessage, 2500);
  }
});



//OTA java
const otaBtn = document.getElementById("checkupdate-btn");
const otaMsg = document.getElementById("ota-message");

let otaPolling = null;

function setOtaUI(state, msg, busy = false) {
  otaMsg.innerText = msg || "";
  otaBtn.disabled = busy;

  if (busy) {
    otaBtn.innerText = "Updating…";
  } else {
    otaBtn.innerText = "Check Update";
  }
}

async function fetchOtaStatus() {
  try {
    const res = await fetch("/api/ota/status", { cache: "no-store" });

    if (!res.ok) {
      throw new Error("OTA API not reachable");
    }

    return await res.json();
  } catch (e) {
    setOtaUI(
      "ERROR",
      "No internet / OTA server unreachable",
      false
    );
    return null;
  }
}

async function pollOtaStatus() {
  const sys = await fetchOtaStatus();
  if (!sys) return;

  switch (sys.UpdateState) {
    case "IDLE":
      setOtaUI("IDLE", "System idle", false);
      clearInterval(otaPolling);
      otaPolling = null;
      break;

    case "CHECKING":
      setOtaUI("CHECKING", "Checking for updates…", true);
      break;

    case "READY":
      setOtaUI("READY", "New firmware available", true);
      break;

    case "DOWNLOADING":
      setOtaUI("DOWNLOADING", "Downloading firmware…", true);
      break;

    case "INSTALLING":
      setOtaUI("INSTALLING", "Installing update…", true);
      break;

    case "DONE":
      setOtaUI(
        "DONE",
        "Update complete. Reboot required.",
        false
      );
      clearInterval(otaPolling);
      otaPolling = null;
      break;

    case "FAILED":
      setOtaUI(
        "FAILED",
        "Update failed. Please try again.",
        false
      );
      clearInterval(otaPolling);
      otaPolling = null;
      break;
  }
}

//auto view port to let user feel change
function updateViewportFromSelect() {

    const resolution = document
        .getElementById("resolution-select")
        .value

    const img = document.getElementById("mjpeg")

    img.classList.remove(
        "res-720p",
        "res-1080p",
        "res-1440p",
        "res-4k"
    )

    switch (resolution.toUpperCase()) {

        case "720P":
            img.classList.add("res-720p")
            break

        case "1080P":
            img.classList.add("res-1080p")
            break

        case "1440P":
            img.classList.add("res-1440p")
            break

        case "4K":
            img.classList.add("res-4k")
            break
    }
}

document
    .getElementById("resolution-select")
    .addEventListener("change", updateViewportFromSelect)

// initial load
updateViewportFromSelect()



otaBtn.addEventListener("click", async () => {
  otaBtn.disabled = true;
  otaMsg.innerText = "Requesting update…";

  try {
    const res = await fetch("/api/ota/request", {
      method: "POST",
      headers: { "Content-Type": "application/json" }
    });

    if (!res.ok) {
      throw new Error("Request failed");
    }

    // Start polling backend state
    otaPolling = setInterval(pollOtaStatus, 1500);

  } catch (e) {
    setOtaUI(
      "ERROR",
      "Cannot contact device",
      false
    );
  }
});

// Initial load
pollOtaStatus();


//end OTA