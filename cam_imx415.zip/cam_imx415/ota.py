import os
import time
import yaml
import threading
import requests
import tarfile
from packaging import version

CONFIG_FILE = "/home/bey/my_flask_app/cam_imx415/config.yaml"
OTA_MANIFEST = "https://raw.githubusercontent.com/BeckMeephanlom/VSI-CAMimx415/main/ota.yaml"
DOWNLOAD_DIR = "/tmp/ota"
APP_DIR = "/home/bey/my_flask_app/cam_imx415"

lock = threading.Lock()


def load_cfg():
    try:
        with open(CONFIG_FILE, "r") as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}


def save_cfg(cfg):
    with open(CONFIG_FILE, "w") as f:
        yaml.dump(cfg, f, sort_keys=False)


def set_state(state):
    with lock:
        cfg = load_cfg()
        cfg.setdefault("System", {})
        cfg["System"]["UpdateState"] = state
        save_cfg(cfg)


def safe_extract(tar, path):
    for member in tar.getmembers():
        member_path = os.path.join(path, member.name)
        if not os.path.abspath(member_path).startswith(os.path.abspath(path)):
            raise Exception("Unsafe tar file")
    tar.extractall(path)


def ota_worker():
    while True:
        time.sleep(2)

        with lock:
            cfg = load_cfg()
            sys = cfg.setdefault("System", {})

            if not sys.get("UpdateRequested"):
                continue

            sys["UpdateRequested"] = False
            sys["UpdateState"] = "CHECKING"
            save_cfg(cfg)

        try:
            r = requests.get(OTA_MANIFEST, timeout=5)
            r.raise_for_status()
            remote = yaml.safe_load(r.text)

            local_ver = version.parse(sys.get("Version", "0"))
            remote_ver = version.parse(remote["System"]["Version"])

            if remote_ver <= local_ver:
                set_state("IDLE")
                continue

            firmware = remote["System"]["Firmware"]
            set_state("READY")

            fw_url = OTA_MANIFEST.replace("ota.yaml", firmware)
            set_state("DOWNLOADING")

            os.makedirs(DOWNLOAD_DIR, exist_ok=True)
            fw_path = os.path.join(DOWNLOAD_DIR, firmware)

            with requests.get(fw_url, stream=True, timeout=10) as r:
                r.raise_for_status()
                with open(fw_path, "wb") as f:
                    for chunk in r.iter_content(8192):
                        f.write(chunk)

            set_state("INSTALLING")

            with tarfile.open(fw_path, "r:gz") as tar:
                safe_extract(tar, APP_DIR)

            with lock:
                cfg = load_cfg()
                sys = cfg.setdefault("System", {})
                sys["Version"] = str(remote_ver)
                sys["RebootRequired"] = True
                sys["UpdateState"] = "DONE"
                save_cfg(cfg)

        except Exception as e:
            print("[OTA] ERROR:", str(e))   # <-- ADD THIS LINE

            with lock:
                cfg = load_cfg()
                cfg["System"]["UpdateState"] = "FAILED"
                cfg["System"]["LastError"] = str(e)
                save_cfg(cfg)


def start_worker():
    t = threading.Thread(target=ota_worker, daemon=True)
    t.start()
